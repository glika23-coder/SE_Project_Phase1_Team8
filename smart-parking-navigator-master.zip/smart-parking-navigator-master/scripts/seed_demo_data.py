from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR))

from app.core.database import Base, SessionLocal, engine
from app.core.security import hash_password
from app.main import ensure_user_role_columns
from app.models.location import Location
from app.models.parking import ParkingSpace
from app.models.search_log import SearchLog  # noqa: F401
from app.models.user import User


DEMO_USERS = [
    ("admin@smartparking.local", "admin123", "admin"),
    ("operator@smartparking.local", "operator123", "operator"),
    ("driver@smartparking.local", "driver123", "driver"),
]

TIRANA_LOCATIONS = [
    {
        "name": "Skanderbeg Square",
        "latitude": 41.3275,
        "longitude": 19.8189,
        "parking": [
            ("Skanderbeg Underground Parking", 180, 42),
            ("National Museum Parking", 60, 0),
        ],
    },
    {
        "name": "Blloku District",
        "latitude": 41.3186,
        "longitude": 19.8156,
        "parking": [
            ("Blloku West Garage", 95, 18),
            ("Ibrahim Rugova Street Parking", 35, 6),
        ],
    },
    {
        "name": "Tirana Artificial Lake",
        "latitude": 41.3128,
        "longitude": 19.8217,
        "parking": [
            ("Lake Park South Lot", 120, 55),
            ("Grand Park Entrance Parking", 80, 12),
        ],
    },
    {
        "name": "New Bazaar",
        "latitude": 41.3291,
        "longitude": 19.8254,
        "parking": [
            ("New Bazaar Public Parking", 70, 9),
            ("Avni Rustemi Square Parking", 45, 0),
        ],
    },
    {
        "name": "Pyramid of Tirana",
        "latitude": 41.3231,
        "longitude": 19.8211,
        "parking": [
            ("Pyramid Visitor Parking", 50, 22),
            ("Deshmoret e Kombit Boulevard Parking", 110, 31),
        ],
    },
    {
        "name": "Air Albania Stadium",
        "latitude": 41.3188,
        "longitude": 19.8235,
        "parking": [
            ("Stadium North Garage", 210, 64),
            ("Arena Event Parking", 160, 0),
        ],
    },
    {
        "name": "Toptani Shopping Center",
        "latitude": 41.3262,
        "longitude": 19.8210,
        "parking": [
            ("Toptani Center Parking", 240, 83),
            ("Castle Street Parking", 40, 5),
        ],
    },
]


def get_or_create_user(email: str, password: str, role: str) -> User:
    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.email == email).first()
        if existing is None:
            existing = User(email=email, password=hash_password(password), role=role)
            db.add(existing)
        else:
            existing.role = role
            if role != "operator":
                existing.assigned_location_id = None
        db.commit()
        db.refresh(existing)
        return existing
    finally:
        db.close()


def seed_locations_and_parking() -> None:
    db = SessionLocal()
    try:
        for item in TIRANA_LOCATIONS:
            location = db.query(Location).filter(Location.name == item["name"]).first()
            if location is None:
                location = Location(
                    name=item["name"],
                    latitude=item["latitude"],
                    longitude=item["longitude"],
                )
                db.add(location)
                db.commit()
                db.refresh(location)

            for parking_name, total_spots, available_spots in item["parking"]:
                existing_space = (
                    db.query(ParkingSpace)
                    .filter(
                        ParkingSpace.location_id == location.location_id,
                        ParkingSpace.name == parking_name,
                    )
                    .first()
                )
                if existing_space is None:
                    db.add(
                        ParkingSpace(
                            location_id=location.location_id,
                            name=parking_name,
                            total_spots=total_spots,
                            available_spots=available_spots,
                            availability_status=available_spots > 0,
                        )
                    )
        db.commit()
    finally:
        db.close()


def main() -> None:
    Base.metadata.create_all(bind=engine)
    ensure_user_role_columns()
    for email, password, role in DEMO_USERS:
        get_or_create_user(email, password, role)
    seed_locations_and_parking()

    db = SessionLocal()
    try:
        operator = db.query(User).filter(User.email == "operator@smartparking.local").first()
        assigned_location = db.query(Location).filter(Location.name == "Skanderbeg Square").first()
        if operator is not None and assigned_location is not None:
            operator.assigned_location_id = assigned_location.location_id
            db.commit()
    finally:
        db.close()

    db = SessionLocal()
    try:
        print("Demo data ready.")
        print(f"Users: {db.query(User).count()}")
        print(f"Locations: {db.query(Location).count()}")
        print(f"Parking spaces: {db.query(ParkingSpace).count()}")
        print("\nDemo accounts:")
        for email, password, role in DEMO_USERS:
            print(f"  {email} / {password} ({role})")
    finally:
        db.close()


if __name__ == "__main__":
    main()

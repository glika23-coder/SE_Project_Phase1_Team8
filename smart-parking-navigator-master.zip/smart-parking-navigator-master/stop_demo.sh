#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_PORT="${BACKEND_PORT:-48100}"
FRONTEND_PORT="${FRONTEND_PORT:-48101}"
LOG_DIR="$ROOT_DIR/demo_logs"
BACKEND_PID_FILE="$LOG_DIR/backend.pid"
FRONTEND_PID_FILE="$LOG_DIR/frontend.pid"

stop_pid_file() {
  local label="$1"
  local pid_file="$2"

  if [ ! -f "$pid_file" ]; then
    echo "$label PID file not found."
    return
  fi

  local pid
  pid="$(cat "$pid_file" 2>/dev/null || true)"
  if [ -z "$pid" ]; then
    echo "$label PID file is empty."
    rm -f "$pid_file"
    return
  fi

  if kill -0 "$pid" 2>/dev/null; then
    echo "Stopping $label process group $pid..."
    kill -- "-$pid" 2>/dev/null || kill "$pid" 2>/dev/null || true
    sleep 1
    if kill -0 "$pid" 2>/dev/null; then
      echo "$label is still running; forcing process group $pid..."
      kill -9 -- "-$pid" 2>/dev/null || kill -9 "$pid" 2>/dev/null || true
    fi
  else
    echo "$label process $pid is not running."
  fi

  rm -f "$pid_file"
}

stop_port() {
  local port="$1"
  if command -v fuser >/dev/null 2>&1; then
    if fuser "$port/tcp" >/dev/null 2>&1; then
      echo "Clearing remaining process on port $port..."
      fuser -k "$port/tcp" >/dev/null 2>&1 || true
    fi
  fi
}

stop_pid_file "frontend" "$FRONTEND_PID_FILE"
stop_pid_file "backend" "$BACKEND_PID_FILE"
stop_port "$FRONTEND_PORT"
stop_port "$BACKEND_PORT"

echo "Demo servers stopped."

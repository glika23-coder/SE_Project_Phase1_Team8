from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session, joinedload

from app.core.database import get_db
from app.core.security import get_current_operator_user
from app.models.location import Location
from app.models.parking import ParkingSpace
from app.models.user import User
from app.schemas.parking import OperatorAvailabilityUpdate, OperatorLocationOut, ParkingSpaceOut
from app.services.parking_service import update_operator_availability

router = APIRouter(prefix="/operator", tags=["operator"])


@router.get("/location", response_model=OperatorLocationOut)
def get_operator_location(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_operator_user),
) -> dict:
    if current_user.assigned_location_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Operator is not assigned to a location",
        )

    location = db.query(Location).filter(Location.location_id == current_user.assigned_location_id).first()
    if location is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Assigned location not found")

    spaces = (
        db.query(ParkingSpace)
        .options(joinedload(ParkingSpace.location))
        .filter(ParkingSpace.location_id == location.location_id)
        .order_by(ParkingSpace.parking_id)
        .all()
    )
    return {"location": location, "parking_spaces": spaces}


@router.patch("/parking/{parking_id}/availability", response_model=ParkingSpaceOut)
def patch_operator_availability(
    parking_id: int,
    payload: OperatorAvailabilityUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_operator_user),
) -> ParkingSpace:
    if current_user.assigned_location_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Operator is not assigned to a location",
        )

    try:
        updated = update_operator_availability(
            db,
            parking_id,
            current_user.assigned_location_id,
            payload.available_spots,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    if updated is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Parking space not found for assigned location",
        )
    return updated

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_admin_user
from app.models.location import Location
from app.schemas.location import LocationCreate, LocationOut
from app.models.user import User

router = APIRouter(prefix="/locations", tags=["locations"])


@router.get("/", response_model=List[LocationOut])
def list_locations(db: Session = Depends(get_db)) -> list[Location]:
    return db.query(Location).all()


@router.get("/{location_id}", response_model=LocationOut)
def get_location(location_id: int, db: Session = Depends(get_db)) -> Location:
    location = db.query(Location).filter(Location.location_id == location_id).first()
    if location is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Location not found")
    return location


@router.post("/", response_model=LocationOut, status_code=status.HTTP_201_CREATED)
def create_location(
    location_in: LocationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user),
) -> Location:
    location = Location(**location_in.model_dump())
    db.add(location)
    db.commit()
    db.refresh(location)
    return location

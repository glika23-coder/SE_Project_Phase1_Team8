from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_admin_user, get_current_user_optional
from app.models.parking import ParkingSpace
from app.models.user import User
from app.schemas.parking import ParkingSpaceCreate, ParkingSpaceOut, ParkingSpaceUpdate
from app.services.parking_service import (
    create_parking_space,
    get_all_parking,
    get_nearby_parking,
    get_parking_by_id,
    search_parking_by_name,
    update_parking_space,
)

router = APIRouter(prefix="/parking", tags=["parking"])


@router.get("/", response_model=List[ParkingSpaceOut])
def list_parking(available_only: bool = Query(False), db: Session = Depends(get_db)) -> List[ParkingSpace]:
    return get_all_parking(db, available_only=available_only)


@router.get("/nearby", response_model=List[ParkingSpaceOut])
def nearby_parking(
    latitude: float = Query(..., ge=-90, le=90),
    longitude: float = Query(..., ge=-180, le=180),
    radius_km: float = Query(5.0, gt=0, le=50),
    available_only: bool = Query(False),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: Session = Depends(get_db),
) -> List[ParkingSpace]:
    user_id = current_user.user_id if current_user else None
    return get_nearby_parking(db, latitude, longitude, radius_km, available_only, user_id)


@router.get("/search", response_model=List[ParkingSpaceOut])
def search_parking(
    q: str = Query(..., min_length=1, max_length=200),
    available_only: bool = Query(False),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: Session = Depends(get_db),
) -> List[ParkingSpace]:
    user_id = current_user.user_id if current_user else None
    return search_parking_by_name(db, q, available_only, user_id)


@router.get("/{parking_id}", response_model=ParkingSpaceOut)
def get_parking(parking_id: int, db: Session = Depends(get_db)) -> ParkingSpace:
    parking_space = get_parking_by_id(db, parking_id)
    if parking_space is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Parking space not found")
    return parking_space


@router.post("/", response_model=ParkingSpaceOut, status_code=status.HTTP_201_CREATED)
def create_parking(
    parking_in: ParkingSpaceCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user),
) -> ParkingSpace:
    try:
        return create_parking_space(db, parking_in)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))


@router.patch("/{parking_id}", response_model=ParkingSpaceOut)
def patch_parking(
    parking_id: int,
    parking_in: ParkingSpaceUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user),
) -> ParkingSpace:
    try:
        updated = update_parking_space(db, parking_id, parking_in)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
    if updated is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Parking space not found")
    return updated

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_admin_user, get_current_user
from app.models.location import Location
from app.models.user import User
from app.schemas.user import UserAssignmentUpdate, UserOut, UserRoleUpdate

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=UserOut)
def get_profile(current_user: User = Depends(get_current_user)) -> User:
    return current_user


@router.get("/", response_model=List[UserOut])
def list_users(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user),
) -> list[User]:
    return db.query(User).order_by(User.user_id).all()


@router.patch("/{user_id}/role", response_model=UserOut)
def update_user_role(
    user_id: int,
    payload: UserRoleUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user),
) -> User:
    user = db.query(User).filter(User.user_id == user_id).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    user.role = payload.role
    if payload.role != "operator":
        user.assigned_location_id = None
    db.commit()
    db.refresh(user)
    return user


@router.patch("/{user_id}/assignment", response_model=UserOut)
def update_user_assignment(
    user_id: int,
    payload: UserAssignmentUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user),
) -> User:
    user = db.query(User).filter(User.user_id == user_id).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    if user.role != "operator":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only operator users can be assigned to a location",
        )
    if payload.assigned_location_id is not None:
        location = db.query(Location).filter(Location.location_id == payload.assigned_location_id).first()
        if location is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Location not found")

    user.assigned_location_id = payload.assigned_location_id
    db.commit()
    db.refresh(user)
    return user

from datetime import datetime
from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.core.database import Base


class SearchLog(Base):
    __tablename__ = "search_logs"

    log_id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.user_id"), nullable=True)
    query = Column(String(500), nullable=True)
    latitude = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)
    results_count = Column(Integer, nullable=False, default=0)
    searched_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    user = relationship("User", back_populates="searches")

from datetime import datetime
from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.core.database import Base


class ParkingSpace(Base):
    __tablename__ = "parking_spaces"

    parking_id = Column(Integer, primary_key=True, index=True)
    location_id = Column(Integer, ForeignKey("locations.location_id"), nullable=False)
    name = Column(String(255), nullable=False)
    availability_status = Column(Boolean, nullable=False, default=True)
    total_spots = Column(Integer, nullable=False, default=1)
    available_spots = Column(Integer, nullable=False, default=1)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)

    location = relationship("Location", back_populates="parking_spaces")

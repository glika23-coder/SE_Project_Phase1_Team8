from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.core.database import Base


class User(Base):
    __tablename__ = "users"

    user_id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default="driver")
    assigned_location_id = Column(Integer, ForeignKey("locations.location_id"), nullable=True)

    searches = relationship("SearchLog", back_populates="user", cascade="all, delete-orphan")
    assigned_location = relationship("Location", foreign_keys=[assigned_location_id])

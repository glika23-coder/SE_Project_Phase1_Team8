import math
from typing import List, Optional

from sqlalchemy.orm import Session, joinedload

from app.models.location import Location
from app.models.parking import ParkingSpace
from app.models.search_log import SearchLog


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def get_all_parking(db: Session, available_only: bool = False) -> List[ParkingSpace]:
    query = db.query(ParkingSpace).options(joinedload(ParkingSpace.location))
    if available_only:
        query = query.filter(ParkingSpace.availability_status.is_(True))
    return query.all()


def get_parking_by_id(db: Session, parking_id: int) -> Optional[ParkingSpace]:
    return (
        db.query(ParkingSpace)
        .options(joinedload(ParkingSpace.location))
        .filter(ParkingSpace.parking_id == parking_id)
        .first()
    )


def get_nearby_parking(
    db: Session,
    latitude: float,
    longitude: float,
    radius_km: float,
    available_only: bool = False,
    user_id: Optional[int] = None,
) -> List[ParkingSpace]:
    spaces = (
        db.query(ParkingSpace)
        .options(joinedload(ParkingSpace.location))
        .all()
    )

    matched: List[ParkingSpace] = []
    for space in spaces:
        if space.location is None:
            continue
        distance = haversine_km(latitude, longitude, space.location.latitude, space.location.longitude)
        if distance > radius_km:
            continue
        if available_only and not space.availability_status:
            continue
        setattr(space, "_distance_km", distance)
        matched.append(space)

    matched.sort(key=lambda space: getattr(space, "_distance_km", 0.0))

    log = SearchLog(
        user_id=user_id,
        latitude=latitude,
        longitude=longitude,
        results_count=len(matched),
    )
    db.add(log)
    db.commit()

    return matched


def search_parking_by_name(db: Session, query_text: str, available_only: bool = False, user_id: Optional[int] = None) -> List[ParkingSpace]:
    query = (
        db.query(ParkingSpace)
        .options(joinedload(ParkingSpace.location))
        .join(Location)
        .filter(Location.name.ilike(f"%{query_text}%"))
    )
    if available_only:
        query = query.filter(ParkingSpace.availability_status.is_(True))

    results = query.all()
    log = SearchLog(user_id=user_id, query=query_text, results_count=len(results))
    db.add(log)
    db.commit()
    return results


def create_parking_space(db: Session, data: "ParkingSpaceCreate") -> ParkingSpace:
    location = db.query(Location).filter(Location.location_id == data.location_id).first()
    if location is None:
        raise ValueError("Location not found")
    if data.available_spots > data.total_spots:
        raise ValueError("available_spots cannot exceed total_spots")

    parking_space = ParkingSpace(
        location_id=data.location_id,
        name=data.name,
        total_spots=data.total_spots,
        available_spots=data.available_spots,
        availability_status=data.available_spots > 0,
    )
    db.add(parking_space)
    db.commit()
    db.refresh(parking_space)
    return parking_space


def update_parking_space(db: Session, parking_id: int, data: "ParkingSpaceUpdate") -> Optional[ParkingSpace]:
    parking_space = db.query(ParkingSpace).filter(ParkingSpace.parking_id == parking_id).first()
    if parking_space is None:
        return None

    if data.total_spots is not None:
        parking_space.total_spots = data.total_spots
        if parking_space.available_spots > data.total_spots:
            parking_space.available_spots = data.total_spots

    if data.available_spots is not None:
        if data.available_spots > parking_space.total_spots:
            raise ValueError("available_spots cannot exceed total_spots")
        parking_space.available_spots = data.available_spots

    parking_space.availability_status = parking_space.available_spots > 0

    db.commit()
    db.refresh(parking_space)
    return parking_space


def update_operator_availability(db: Session, parking_id: int, location_id: int, available_spots: int) -> Optional[ParkingSpace]:
    parking_space = (
        db.query(ParkingSpace)
        .filter(
            ParkingSpace.parking_id == parking_id,
            ParkingSpace.location_id == location_id,
        )
        .first()
    )
    if parking_space is None:
        return None
    if available_spots > parking_space.total_spots:
        raise ValueError("available_spots cannot exceed total_spots")

    parking_space.available_spots = available_spots
    parking_space.availability_status = available_spots > 0
    db.commit()
    db.refresh(parking_space)
    return parking_space

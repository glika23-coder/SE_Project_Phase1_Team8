from pydantic import BaseModel, field_validator


class LocationCreate(BaseModel):
    name: str
    latitude: float
    longitude: float

    @field_validator("latitude")
    @classmethod
    def validate_latitude(cls, value: float) -> float:
        if not (-90 <= value <= 90):
            raise ValueError("Latitude must be between -90 and 90")
        return value

    @field_validator("longitude")
    @classmethod
    def validate_longitude(cls, value: float) -> float:
        if not (-180 <= value <= 180):
            raise ValueError("Longitude must be between -180 and 180")
        return value


class LocationOut(BaseModel):
    location_id: int
    name: str
    latitude: float
    longitude: float

    model_config = {"from_attributes": True}

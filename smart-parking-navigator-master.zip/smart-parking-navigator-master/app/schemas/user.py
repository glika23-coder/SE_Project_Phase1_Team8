from typing import Literal

from pydantic import BaseModel, EmailStr, field_validator

UserRole = Literal["driver", "operator", "admin"]


class UserCreate(BaseModel):
    email: EmailStr
    password: str

    @field_validator("password")
    @classmethod
    def validate_password(cls, value: str) -> str:
        if len(value) < 8:
            raise ValueError("Password must be at least 8 characters")
        return value


class UserOut(BaseModel):
    user_id: int
    email: str
    role: UserRole
    assigned_location_id: int | None = None

    model_config = {"from_attributes": True}


class UserRoleUpdate(BaseModel):
    role: UserRole


class UserAssignmentUpdate(BaseModel):
    assigned_location_id: int | None = None


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    user_id: int | None = None

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field, field_validator

from app.schemas.location import LocationOut


class ParkingSpaceCreate(BaseModel):
    location_id: int
    name: str
    total_spots: int
    available_spots: int

    @field_validator("total_spots", "available_spots")
    @classmethod
    def non_negative(cls, value: int) -> int:
        if value < 0:
            raise ValueError("Must be greater than or equal to 0")
        return value


class ParkingSpaceUpdate(BaseModel):
    available_spots: Optional[int] = None
    total_spots: Optional[int] = None

    @field_validator("total_spots", "available_spots")
    @classmethod
    def update_non_negative(cls, value: Optional[int]) -> Optional[int]:
        if value is not None and value < 0:
            raise ValueError("Must be greater than or equal to 0")
        return value


class OperatorAvailabilityUpdate(BaseModel):
    available_spots: int

    @field_validator("available_spots")
    @classmethod
    def availability_non_negative(cls, value: int) -> int:
        if value < 0:
            raise ValueError("Must be greater than or equal to 0")
        return value


class ParkingSpaceOut(BaseModel):
    parking_id: int
    name: str
    availability_status: bool
    total_spots: int
    available_spots: int
    updated_at: Optional[datetime]
    location: LocationOut

    model_config = {"from_attributes": True}


class OperatorLocationOut(BaseModel):
    location: LocationOut
    parking_spaces: list[ParkingSpaceOut]


class NearbySearchParams(BaseModel):
    latitude: float
    longitude: float
    radius_km: float = Field(5.0, gt=0, le=50)
    available_only: bool = False

    @field_validator("latitude")
    @classmethod
    def validate_latitude(cls, value: float) -> float:
        if not (-90 <= value <= 90):
            raise ValueError("Latitude must be between -90 and 90")
        return value

    @field_validator("longitude")
    @classmethod
    def validate_longitude(cls, value: float) -> float:
        if not (-180 <= value <= 180):
            raise ValueError("Longitude must be between -180 and 180")
        return value

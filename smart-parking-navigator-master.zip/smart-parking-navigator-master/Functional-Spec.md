# Smart Parking Navigator — Functional & Technical Specification

> **Who this doc is for:** You are implementing this backend yourself. Every file in the project is described below with what it does, what rules it enforces, and concrete hints on how to write it. Read the section for a file before you open it in your editor.

---

## Table of Contents

1. [How the pieces fit together](#1-how-the-pieces-fit-together)
2. [Configuration — `app/core/config.py`](#2-configuration--appccoreconfigpy)
3. [Database — `app/core/database.py`](#3-database--appcoredatabasepy)
4. [Security — `app/core/security.py`](#4-security--appcoresecuritypy)
5. [Models](#5-models)
   - [User — `app/models/user.py`](#51-user--appmodelsuserpy)
   - [Location — `app/models/location.py`](#52-location--appmodelslocationpy)
   - [ParkingSpace — `app/models/parking.py`](#53-parkingspace--appmodelsparkingpy)
   - [SearchLog — `app/models/search_log.py`](#54-searchlog--appmodelssearch_logpy)
6. [Schemas](#6-schemas)
   - [User Schemas — `app/schemas/user.py`](#61-user-schemas--appschemsuserpy)
   - [Location Schemas — `app/schemas/location.py`](#62-location-schemas--appschemaslocationpy)
   - [Parking Schemas — `app/schemas/parking.py`](#63-parking-schemas--appschemassparkingpy)
7. [Routers](#7-routers)
   - [Auth — `app/routers/auth.py`](#71-auth--approutersauthpy)
   - [Users — `app/routers/users.py`](#72-users--approutersuserspy)
   - [Locations — `app/routers/locations.py`](#73-locations--approuterslocationspy)
   - [Parking — `app/routers/parking.py`](#74-parking--approuterssparkingpy)
8. [Service Layer — `app/services/parking_service.py`](#8-service-layer--appservicesparking_servicepy)
9. [App Entry Point — `app/main.py`](#9-app-entry-point--appmainpy)
10. [Tests — `tests/test_parking_service.py`](#10-tests--teststest_parking_servicepy)
11. [Supporting Files](#11-supporting-files)
    - [`requirements.txt`](#111-requirementstxt)
    - [`.env.example`](#112-envexample)
    - [`alembic.ini`](#113-alembicini)
12. [Error Reference](#12-error-reference)
13. [Data Flow Diagrams](#13-data-flow-diagrams)

---

## 1. How the pieces fit together

The backend follows a strict **three-layer architecture**. Understanding this upfront will save you a lot of confusion:

```
HTTP Request
     │
     ▼
┌─────────────┐
│   Router    │  Receives the request, validates path/query params,
│ (routers/)  │  calls the service, returns the HTTP response.
└──────┬──────┘
       │ calls
       ▼
┌─────────────┐
│   Service   │  Contains all business logic (distance calculation,
│ (services/) │  filtering, logging). Never touches HTTP directly.
└──────┬──────┘
       │ queries
       ▼
┌─────────────┐
│   Model     │  SQLAlchemy ORM classes that map to MySQL tables.
│  (models/)  │  No logic here — just column definitions.
└─────────────┘
```

**Schemas** (`schemas/`) are separate from models. They describe the shape of data coming **in** from the client (request bodies) and going **out** to the client (responses). A model is a database row; a schema is a JSON shape.

**Core** (`core/`) holds shared infrastructure that everything else imports: config, the database session factory, and security utilities.

**Rule:** Routers never touch the database directly. All DB work goes through the service layer (or in simple CRUD cases, through the router — but keep it consistent).

---

## 2. Configuration — `app/core/config.py`

### What it does

Reads environment variables from a `.env` file and exposes them as a typed Python object called `settings`. Every other file imports from here instead of reading `os.environ` directly.

### Functional requirements

- Must expose four settings: `DATABASE_URL`, `SECRET_KEY`, `ACCESS_TOKEN_EXPIRE_MINUTES`, `MAPS_API_KEY`.
- Must have safe defaults so the app starts without a `.env` file (for local testing), but the defaults must never be used in production.
- Settings must be readable from a `.env` file in the project root.

### Technical hints

- Use `pydantic-settings` (`from pydantic_settings import BaseSettings`). This is different from plain `pydantic` — it adds `.env` file loading on top.
- Define a class that extends `BaseSettings`. Each class attribute is one setting. The type annotation (`str`, `int`) controls automatic type coercion — if `ACCESS_TOKEN_EXPIRE_MINUTES=60` is a string in `.env`, pydantic converts it to `int` automatically.
- Add an inner `class Config` with `env_file = ".env"` so pydantic knows where to look.
- Create a single `settings = Settings()` instance at module level. All other files import this one instance — do not create multiple instances.

```python
# Pattern to follow
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    MY_VAR: str = "default_value"
    MY_INT: int = 42

    class Config:
        env_file = ".env"

settings = Settings()
```

---

## 3. Database — `app/core/database.py`

### What it does

Creates the SQLAlchemy database engine (the connection to MySQL), a session factory, a base class for all models, and a `get_db` dependency function that routers use to obtain a database session per request.

### Functional requirements

- Must connect to MySQL using the `DATABASE_URL` from `settings`.
- Must use a connection pool (so multiple users share connections rather than opening a new one per request).
- Must provide a `get_db()` generator that opens a session, yields it to the caller, and **always** closes it afterwards — even if an exception occurs.
- Must provide a `Base` class that all models inherit from.

### Technical hints

- `create_engine(url, pool_pre_ping=True)` — `pool_pre_ping=True` makes SQLAlchemy test connections before using them, preventing "stale connection" errors after MySQL goes idle.
- `pool_size=10, max_overflow=20` means up to 10 persistent connections, with 20 extra allowed under load burst. Tune these for your server.
- `SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)` — always use `autocommit=False` so you control when changes are written with `db.commit()`.
- The `get_db` function must be a **generator** using `yield`. FastAPI's dependency injection system calls it before the route handler and resumes after to run cleanup:

```python
def get_db():
    db = SessionLocal()
    try:
        yield db       # FastAPI passes this db to the route handler
    finally:
        db.close()     # always runs, even on error
```

- `DeclarativeBase` is the modern SQLAlchemy 2.x way to create `Base`. Older tutorials use `declarative_base()` — both work, but stay consistent with one style.

---

## 4. Security — `app/core/security.py`

### What it does

Provides three things: password hashing/verification, JWT token creation, and a FastAPI dependency (`get_current_user`) that any protected route can use to identify who is making the request.

### Functional requirements

- Passwords must be hashed with bcrypt before storage. Plain-text passwords must never be stored.
- JWTs must be signed with `SECRET_KEY` using the HS256 algorithm.
- Tokens must expire after `ACCESS_TOKEN_EXPIRE_MINUTES` minutes.
- `get_current_user` must raise `HTTP 401` if the token is missing, expired, malformed, or refers to a deleted user.
- The token payload must store the user's `user_id` under the key `"sub"` (subject — standard JWT convention).

### Technical hints

**Password hashing** — use `passlib`:
```python
from passlib.context import CryptContext
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(plain: str) -> str:
    return pwd_context.hash(plain)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)
```

**JWT creation** — use `python-jose`:
```python
from jose import jwt
from datetime import datetime, timedelta

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    to_encode["exp"] = datetime.utcnow() + timedelta(minutes=60)
    return jwt.encode(to_encode, SECRET_KEY, algorithm="HS256")
```

**Protecting routes** — `OAuth2PasswordBearer` reads the `Authorization: Bearer <token>` header automatically. Use it as a FastAPI dependency:
```python
from fastapi.security import OAuth2PasswordBearer
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

def get_current_user(token: str = Depends(oauth2_scheme), db = Depends(get_db)):
    # decode token, look up user, return User object or raise 401
```

**Making a route optional-auth** — declare the dependency as `Optional[User] = Depends(get_current_user)`. If no token is sent, FastAPI will pass `None`. The nearby and search parking endpoints use this pattern so anonymous users can still search.

---

## 5. Models

Models are Python classes that map 1-to-1 with MySQL tables. They contain column definitions and relationship declarations — no business logic. All models inherit from `Base` (from `database.py`).

### 5.1 User — `app/models/user.py`

**Table name:** `users`

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `user_id` | Integer | Primary key, auto-increment, indexed | |
| `email` | String(255) | Unique, not null, indexed | Index speeds up login lookups |
| `password` | String(255) | Not null | Stores bcrypt hash, not plain text |

**Relationships:**
- Has many `SearchLog` records via `searches`. Use `cascade="all, delete-orphan"` so search logs are deleted if a user is deleted.

**Hint:** The `unique=True` on email is enforced at the database level. Your router must also check for duplicates before inserting (and handle the `409 Conflict` case).

---

### 5.2 Location — `app/models/location.py`

**Table name:** `locations`

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `location_id` | Integer | Primary key, auto-increment, indexed | |
| `name` | String(255) | Not null | Human-readable name e.g. "Downtown Mall" |
| `latitude` | Float | Not null | Decimal degrees e.g. 25.2048 |
| `longitude` | Float | Not null | Decimal degrees e.g. 55.2708 |

**Relationships:**
- Has many `ParkingSpace` records via `parking_spaces`.

**Hint:** `Float` in SQLAlchemy maps to a 64-bit double in MySQL (`DOUBLE`), which gives you about 15 decimal digits of precision — more than enough for GPS coordinates.

---

### 5.3 ParkingSpace — `app/models/parking.py`

**Table name:** `parking_spaces`

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `parking_id` | Integer | Primary key, auto-increment, indexed | |
| `location_id` | Integer | Foreign key → `locations.location_id`, not null | |
| `name` | String(255) | Not null | e.g. "Level 2 - North Wing" |
| `availability_status` | Boolean | Not null, default True | True = at least one spot available |
| `total_spots` | Integer | Not null, default 1 | Total capacity |
| `available_spots` | Integer | Not null, default 1 | Current free count |
| `updated_at` | DateTime | Auto-set on create and update | Tracks freshness of availability data |

**Relationships:**
- Belongs to one `Location` via `location`.

**Key business rule:** `availability_status` is derived from `available_spots`. When `available_spots` is updated in the service layer, `availability_status` is automatically recalculated: `availability_status = available_spots > 0`. Do not let them get out of sync.

**Hint on `updated_at`:** Use `default=datetime.utcnow` (without calling it — pass the function, not its return value) and `onupdate=datetime.utcnow` so SQLAlchemy updates this column automatically on every `db.commit()` that touches this row.

---

### 5.4 SearchLog — `app/models/search_log.py`

**Table name:** `search_logs`

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `log_id` | Integer | Primary key, auto-increment, indexed | |
| `user_id` | Integer | Foreign key → `users.user_id`, nullable | Null = anonymous search |
| `query` | String(500) | Nullable | Populated for name searches |
| `latitude` | Float | Nullable | Populated for coordinate searches |
| `longitude` | Float | Nullable | Populated for coordinate searches |
| `results_count` | Integer | Default 0 | How many results were returned |
| `searched_at` | DateTime | Default now | Timestamp of the search |

**Relationships:**
- Belongs to one `User` via `user` (nullable — anonymous users have no account).

**Purpose:** This table satisfies the spec requirement to "log system activity". It records every search so you can analyse usage patterns (which areas are searched most, what search terms are popular, etc.) without the user needing to know.

---

## 6. Schemas

Schemas are Pydantic models. They are **not** database tables — they describe the shape of JSON going in and out of the API. FastAPI uses them to validate requests automatically and to serialise responses.

**Rule of thumb:**
- `*Create` schema — what the client sends in the request body to create something.
- `*Update` schema — what the client sends to partially update something (all fields optional).
- `*Out` schema — what the API returns to the client. Never includes passwords.

---

### 6.1 User Schemas — `app/schemas/user.py`

**`UserCreate`** (request body for registration):
- `email: EmailStr` — pydantic's `EmailStr` validates email format automatically. Requires `pip install 'pydantic[email]'` (already in requirements).
- `password: str` — must be at least 8 characters. Enforce this with a `@field_validator`.

**`UserOut`** (response body — what is returned after register or when fetching profile):
- `user_id: int`
- `email: str`
- Must include `model_config = {"from_attributes": True}` so pydantic can read attributes from a SQLAlchemy model object (not just a plain dict).
- **Never include `password` here.** This is how you prevent leaking hashed passwords in API responses.

**`Token`** (response body for login):
- `access_token: str` — the JWT string.
- `token_type: str = "bearer"` — always `"bearer"`, hardcoded as default.

**`TokenData`** (internal use — not an API response):
- `user_id: int | None = None` — used inside `get_current_user` to hold the decoded token payload. The client never sees this.

---

### 6.2 Location Schemas — `app/schemas/location.py`

**`LocationCreate`** (request body):
- `name: str`
- `latitude: float` — validated: must be between -90 and 90.
- `longitude: float` — validated: must be between -180 and 180.

**`LocationOut`** (response body):
- `location_id: int`, `name: str`, `latitude: float`, `longitude: float`
- Include `model_config = {"from_attributes": True}`.

**Hint on validators:** Use `@field_validator("latitude")` with `@classmethod`:
```python
@field_validator("latitude")
@classmethod
def validate_lat(cls, v: float) -> float:
    if not (-90 <= v <= 90):
        raise ValueError("Latitude must be between -90 and 90")
    return v
```

---

### 6.3 Parking Schemas — `app/schemas/parking.py`

**`ParkingSpaceCreate`** (request body):
- `location_id: int`, `name: str`, `total_spots: int`, `available_spots: int`
- Both `total_spots` and `available_spots` must be ≥ 0 (validated).

**`ParkingSpaceUpdate`** (request body for PATCH):
- `available_spots: Optional[int] = None`
- `availability_status: Optional[bool] = None`
- All fields optional — a PATCH only updates what you send.

**`ParkingSpaceOut`** (response body):
- `parking_id`, `name`, `availability_status`, `total_spots`, `available_spots`, `updated_at`
- Also includes the **nested** `location: LocationOut` — the full location object is embedded in the parking space response so the client doesn't need a second API call.
- Include `model_config = {"from_attributes": True}`.

**`NearbySearchParams`** (used internally for validation — not a direct request body, but mirrors the query params):
- `latitude: float` (validated -90 to 90)
- `longitude: float` (validated -180 to 180)
- `radius_km: float = 5.0` (validated: must be > 0 and ≤ 50)
- `available_only: bool = False`

---

## 7. Routers

Routers handle HTTP. Their only jobs are: parse the incoming request, call the service or model, return an HTTP response. Keep them thin.

### 7.1 Auth — `app/routers/auth.py`

**Prefix:** `/auth` — so endpoints are `/api/v1/auth/...`

---

#### `POST /register`

- **Auth required:** No
- **Request body:** `UserCreate` (email + password)
- **Success response:** `201 Created` with `UserOut` body
- **Error cases:**
  - `409 Conflict` — email already registered

**Logic:**
1. Query the `users` table for a row matching the email.
2. If found, raise `HTTPException(409)`.
3. Hash the password using `hash_password()` from security.
4. Create a `User` model instance, add to DB, commit, refresh.
5. Return the user object (pydantic serialises it via `UserOut`).

---

#### `POST /login`

- **Auth required:** No
- **Request body:** `OAuth2PasswordRequestForm` — this is a FastAPI special form that reads `username` and `password` as `application/x-www-form-urlencoded` (not JSON). The field is named `username` by the OAuth2 standard even though we use email.
- **Success response:** `200 OK` with `Token` body
- **Error cases:**
  - `401 Unauthorized` — wrong email or wrong password (same error for both — do not reveal which one is wrong)

**Logic:**
1. Look up user by `form.username` (which is the email the client sends).
2. If not found, or if `verify_password(form.password, user.password)` is False → raise `HTTPException(401)`.
3. Call `create_access_token({"sub": str(user.user_id)})`.
4. Return `{"access_token": token, "token_type": "bearer"}`.

**Important:** The `Authorization` header hint — tell the client (in your API docs) to send: `Authorization: Bearer <token>` on subsequent requests.

---

### 7.2 Users — `app/routers/users.py`

**Prefix:** `/users`

---

#### `GET /me`

- **Auth required:** Yes
- **Success response:** `200 OK` with `UserOut`

**Logic:** `get_current_user` dependency does all the work — it decodes the token and returns the `User` object. The route just returns it.

```python
@router.get("/me", response_model=UserOut)
def get_profile(current_user: User = Depends(get_current_user)):
    return current_user
```

This is the shortest route in the project. It demonstrates how dependencies eliminate boilerplate.

---

### 7.3 Locations — `app/routers/locations.py`

**Prefix:** `/locations`

---

#### `GET /`

- **Auth required:** No
- **Success response:** `200 OK` with `List[LocationOut]`

**Logic:** `db.query(Location).all()` — return all locations.

---

#### `GET /{location_id}`

- **Auth required:** No
- **Success response:** `200 OK` with `LocationOut`
- **Error cases:** `404 Not Found` — location ID does not exist

**Logic:** Query by `location_id`. If `None`, raise `HTTPException(404)`.

---

#### `POST /`

- **Auth required:** Yes
- **Request body:** `LocationCreate`
- **Success response:** `201 Created` with `LocationOut`

**Logic:** Create `Location` object, add to DB, commit, refresh, return.

---

### 7.4 Parking — `app/routers/parking.py`

**Prefix:** `/parking` — this is the most complex router.

---

#### `GET /`

- **Auth required:** No
- **Query params:** `available_only: bool = False`
- **Success response:** `200 OK` with `List[ParkingSpaceOut]`

**Logic:** Calls `parking_service.get_all_parking(db)`. Note: the `available_only` param is declared but the current service implementation returns all spaces — you would extend the service to filter if needed.

---

#### `GET /nearby`

- **Auth required:** Optional (anonymous users can search too)
- **Query params:**
  - `latitude: float` (required, -90 to 90)
  - `longitude: float` (required, -180 to 180)
  - `radius_km: float = 5.0` (max 50)
  - `available_only: bool = False`
- **Success response:** `200 OK` with `List[ParkingSpaceOut]` sorted nearest-first

**Logic:** Delegates entirely to `parking_service.get_nearby_parking()`. The route validates query params using FastAPI's `Query(...)` with `ge`/`le` constraints.

**Important route ordering:** In FastAPI, routes with literal path segments must come before routes with path parameters on the same prefix. `/nearby` must be defined **before** `/{parking_id}` in the file, otherwise FastAPI will try to match "nearby" as a parking ID integer and fail.

---

#### `GET /search`

- **Auth required:** Optional
- **Query params:**
  - `q: str` (required, 1–200 chars) — the search term
  - `available_only: bool = False`
- **Success response:** `200 OK` with `List[ParkingSpaceOut]`

**Logic:** Delegates to `parking_service.search_parking_by_name()`.

---

#### `GET /{parking_id}`

- **Auth required:** No
- **Path param:** `parking_id: int`
- **Success response:** `200 OK` with `ParkingSpaceOut`
- **Error cases:** `404 Not Found`

**Logic:** Calls `parking_service.get_parking_by_id()`. Raises 404 if not found.

---

#### `POST /`

- **Auth required:** Yes
- **Request body:** `ParkingSpaceCreate`
- **Success response:** `201 Created` with `ParkingSpaceOut`
- **Error cases:** `400 Bad Request` — if `location_id` doesn't exist

**Logic:** Calls `parking_service.create_parking_space()`. The service raises `ValueError` if the location is not found — the router catches this and converts it to `HTTPException(400)`.

---

#### `PATCH /{parking_id}`

- **Auth required:** Yes
- **Path param:** `parking_id: int`
- **Request body:** `ParkingSpaceUpdate` (all fields optional)
- **Success response:** `200 OK` with updated `ParkingSpaceOut`
- **Error cases:**
  - `400 Bad Request` — `available_spots` > `total_spots`
  - `404 Not Found` — parking ID does not exist

**Logic:** Calls `parking_service.update_parking_space()`. Service raises `ValueError` on invalid data, returns `None` if not found.

---

## 8. Service Layer — `app/services/parking_service.py`

This is the brain of the application. All non-trivial logic lives here. Routers call these functions; functions talk to the DB.

---

### `haversine_km(lat1, lon1, lat2, lon2) → float`

Calculates the straight-line distance in kilometres between two GPS coordinates using the Haversine formula. This is the mathematical core of the nearby search.

**How it works:**
1. Convert degrees to radians for both points.
2. Calculate the angular differences.
3. Apply the Haversine formula to get the central angle.
4. Multiply by Earth's radius (6371 km) to get the distance.

**Why not use SQL for this?** MySQL can do geospatial queries, but that requires spatial column types and indexes. The Python approach here is simpler to implement and sufficient for small datasets. For large datasets (10,000+ parking spaces), consider switching to a spatial query.

```python
import math

def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
```

---

### `get_nearby_parking(db, latitude, longitude, radius_km, available_only, user_id) → List[ParkingSpace]`

**Steps:**
1. Fetch all parking spaces joined with their location: `db.query(ParkingSpace).join(Location).all()`
2. For each space, call `haversine_km` with the user's coordinates and the space's location coordinates.
3. Include the space only if the distance is ≤ `radius_km`.
4. If `available_only=True`, also exclude spaces where `availability_status` is False.
5. Attach the distance as a temporary attribute (`space._distance_km`) so you can sort by it.
6. Sort the results list by `_distance_km` ascending (nearest first).
7. Write a `SearchLog` record (with coordinates and result count) and commit.
8. Return the sorted list.

**Note on `_distance_km`:** This is a dynamically attached Python attribute — it does not exist in the database column. It's only used for sorting and is not serialised into the API response (because `ParkingSpaceOut` doesn't include it).

---

### `search_parking_by_name(db, query, available_only, user_id) → List[ParkingSpace]`

**Steps:**
1. Query parking spaces joined with location, filtering by `Location.name.ilike(f"%{query}%")`. `ilike` is case-insensitive LIKE.
2. If `available_only=True`, add `.filter(ParkingSpace.availability_status == True)`.
3. Write a `SearchLog` record (with the query text and result count) and commit.
4. Return results.

**`ilike` vs `like`:** `ilike` is case-insensitive. "downtown" matches "Downtown", "DOWNTOWN", "downtOwN". Always use `ilike` for user-facing search.

---

### `create_parking_space(db, data: ParkingSpaceCreate) → ParkingSpace`

**Steps:**
1. Check that `data.location_id` exists: `db.query(Location).filter(...).first()`. If not found, `raise ValueError(...)`.
2. Create a `ParkingSpace` instance. Derive `availability_status` automatically: `availability_status = data.available_spots > 0`.
3. `db.add(space)`, `db.commit()`, `db.refresh(space)`, return.

**Why `db.refresh`?** After commit, the object in memory may be stale (e.g., the auto-generated `parking_id` isn't populated yet). `refresh` reloads it from the database.

---

### `update_parking_space(db, parking_id, data: ParkingSpaceUpdate) → Optional[ParkingSpace]`

**Steps:**
1. Fetch the space by ID. If not found, return `None` (the router converts this to 404).
2. If `data.available_spots` is not None:
   - Validate it doesn't exceed `space.total_spots`. If it does, `raise ValueError(...)`.
   - Update both `space.available_spots` and `space.availability_status = data.available_spots > 0`.
3. If `data.availability_status` is not None, update it directly. (This allows manually overriding the status independently of the spot count.)
4. `db.commit()`, `db.refresh(space)`, return.

---

### `get_all_parking(db) → List[ParkingSpace]`

Simple: `db.query(ParkingSpace).join(Location).all()`. The `join(Location)` is needed so the `location` relationship is available without triggering a lazy-load error when pydantic tries to read it.

---

### `get_parking_by_id(db, parking_id) → Optional[ParkingSpace]`

Simple: `db.query(ParkingSpace).filter(ParkingSpace.parking_id == parking_id).first()`. Returns `None` if not found.

---

## 9. App Entry Point — `app/main.py`

### What it does

Creates the FastAPI application, configures middleware, registers all routers, and creates the database tables on startup.

### Functional requirements

- All routes must be prefixed with `/api/v1`.
- CORS must be enabled so a browser-based frontend (on a different port or domain) can call the API.
- Unhandled exceptions must return a clean JSON error response, not a Python traceback.
- The app must expose Swagger UI at `/docs` and ReDoc at `/redoc`.
- A health-check endpoint at `GET /` must return `{"status": "ok"}`.

### Technical hints

**Creating the app:**
```python
app = FastAPI(title="Smart Parking Navigator API", version="1.0.0")
```

**Auto-creating tables on startup** (development only):
```python
Base.metadata.create_all(bind=engine)
```
This reads all your model classes and creates any missing tables. For production, use Alembic migrations instead (see section 11.3).

**CORS middleware** — must be added before routes:
```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],      # Change to your frontend URL in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

**Global exception handler:**
```python
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    return JSONResponse(status_code=500, content={"detail": "Unexpected error"})
```

**Registering routers:**
```python
API_PREFIX = "/api/v1"
app.include_router(auth.router, prefix=API_PREFIX)
app.include_router(users.router, prefix=API_PREFIX)
app.include_router(locations.router, prefix=API_PREFIX)
app.include_router(parking.router, prefix=API_PREFIX)
```

Each router also has its own prefix (`/auth`, `/users`, etc.) defined inside the router file, so the final paths are `/api/v1/auth/...`, `/api/v1/users/...`, etc.

---

## 10. Tests — `tests/test_parking_service.py`

### What it does

Tests the `haversine_km` function with three cases — no database required.

### Functional requirements

- Tests must pass without a database connection.
- Must test the zero-distance case (same point).
- Must test a known real-world distance.
- Must test symmetry (A→B == B→A).

### Technical hints

- Use `pytest.approx()` for floating-point comparisons. Floats are never exactly equal — `pytest.approx` allows for small rounding differences:
```python
assert haversine_km(0, 0, 0, 0) == pytest.approx(0.0)
```

**Run tests with:**
```bash
pytest tests/ -v
```

**To expand the test suite** (your task as the implementer), consider adding:
- Tests for `create_parking_space` using an in-memory SQLite database.
- Tests for `update_parking_space` checking that `available_spots > total_spots` raises correctly.
- Integration tests using FastAPI's `TestClient` to test full HTTP request/response cycles.

---

## 11. Supporting Files

### 11.1 `requirements.txt`

Pin all dependencies at exact versions for reproducible installs. Key packages and why they're needed:

| Package | Purpose |
|---|---|
| `fastapi` | The web framework |
| `uvicorn[standard]` | ASGI server that runs FastAPI |
| `sqlalchemy` | ORM for database models and queries |
| `pymysql` | MySQL driver (SQLAlchemy uses this to talk to MySQL) |
| `cryptography` | Required by pymysql for SSL support |
| `pydantic` | Data validation (FastAPI uses this internally) |
| `pydantic-settings` | Reads `.env` files into config classes |
| `passlib[bcrypt]` | Password hashing |
| `python-jose[cryptography]` | JWT creation and verification |
| `python-multipart` | Required for `OAuth2PasswordRequestForm` (form data parsing) |
| `httpx` | HTTP client (useful for testing with `TestClient`) |
| `alembic` | Database migration tool |
| `pytest` | Test runner |
| `pytest-asyncio` | Enables async tests in pytest |

**Install all:** `pip install -r requirements.txt`

---

### 11.2 `.env.example`

A template showing required environment variables. Copy to `.env` and fill in your values. Never commit `.env` to version control — only commit `.env.example`.

| Variable | Description | Example |
|---|---|---|
| `DATABASE_URL` | Full MySQL connection string | `mysql+pymysql://root:password@localhost:3306/smart_parking` |
| `SECRET_KEY` | Random string used to sign JWTs | Generate with: `python -c "import secrets; print(secrets.token_hex(32))"` |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | How long tokens stay valid | `60` (1 hour) |
| `MAPS_API_KEY` | Google Maps API key | From Google Cloud Console |

---

### 11.3 `alembic.ini`

Configuration for Alembic, the database migration tool. Alembic tracks changes to your models over time and generates SQL scripts to update the database schema.

**Why you need it:** `Base.metadata.create_all()` only creates tables that don't exist — it won't alter existing tables if you add a column. Alembic handles schema evolution properly.

**Basic Alembic workflow:**
```bash
# Initialise (one time)
alembic init alembic

# After changing a model, generate a migration
alembic revision --autogenerate -m "add phone column to users"

# Apply pending migrations
alembic upgrade head
```

**For now (development):** You can rely on `create_all()`. Switch to Alembic before deploying to a real server.

---

## 12. Error Reference

All errors returned by the API follow the FastAPI standard format:
```json
{ "detail": "Human-readable error message" }
```

| HTTP Status | When it occurs |
|---|---|
| `400 Bad Request` | Invalid input (e.g. `available_spots > total_spots`, location not found when creating a parking space) |
| `401 Unauthorized` | Missing or invalid JWT token, wrong email/password |
| `404 Not Found` | Resource ID does not exist |
| `409 Conflict` | Email already registered |
| `422 Unprocessable Entity` | Request body failed Pydantic validation (automatic — FastAPI handles this) |
| `500 Internal Server Error` | Unexpected exception (caught by global handler) |

---

## 13. Data Flow Diagrams

### Registration flow
```
Client → POST /api/v1/auth/register {email, password}
  → auth router
    → check email uniqueness (DB query)
    → hash_password()
    → insert User row
    → return UserOut (no password field)
```

### Login flow
```
Client → POST /api/v1/auth/login {username=email, password}
  → auth router
    → find User by email
    → verify_password()
    → create_access_token({sub: user_id})
    → return {access_token, token_type}
```

### Nearby search flow (authenticated)
```
Client → GET /api/v1/parking/nearby?latitude=X&longitude=Y&radius_km=2
         Authorization: Bearer <token>
  → parking router
    → get_current_user() decodes JWT → User object
    → parking_service.get_nearby_parking()
      → fetch all ParkingSpace + Location from DB
      → for each: haversine_km(user_coords, space_coords)
      → filter by radius
      → sort by distance
      → write SearchLog row
    → return List[ParkingSpaceOut]
```

### Availability update flow
```
Client → PATCH /api/v1/parking/42 {available_spots: 3}
         Authorization: Bearer <token>
  → parking router
    → get_current_user() → User object
    → parking_service.update_parking_space(db, 42, data)
      → fetch ParkingSpace by ID
      → validate available_spots ≤ total_spots
      → update available_spots
      → recalculate availability_status = (available_spots > 0)
      → db.commit()
    → return updated ParkingSpaceOut
```

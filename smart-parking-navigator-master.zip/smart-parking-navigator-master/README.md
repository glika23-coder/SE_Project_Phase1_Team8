# Smart Parking Navigator

## Overview

The Smart Parking Navigator is a web application designed to help users find available parking spaces in real-time. It provides a user-friendly interface for searching and managing parking locations, leveraging a robust backend built with FastAPI and SQLAlchemy.

## Features

- User registration and authentication
- Search for nearby parking spaces based on GPS coordinates
- View details of parking spaces, including availability
- Log search queries for analytics
- Admin capabilities for managing parking locations and spaces

## Project Structure

```
smart-parking-navigator
├── app
│   ├── core
│   │   ├── config.py          # Configuration management using pydantic-settings
│   │   ├── database.py        # Database engine and session management
│   │   └── security.py        # Password hashing and JWT token management
│   ├── models
│   │   ├── user.py            # User model for database
│   │   ├── location.py        # Location model for database
│   │   ├── parking.py         # ParkingSpace model for database
│   │   └── search_log.py      # SearchLog model for database
│   ├── schemas
│   │   ├── user.py            # Pydantic schemas for user data
│   │   ├── location.py        # Pydantic schemas for location data
│   │   └── parking.py         # Pydantic schemas for parking data
│   ├── routers
│   │   ├── auth.py            # Authentication routes
│   │   ├── users.py           # User-related routes
│   │   ├── locations.py       # Location-related routes
│   │   └── parking.py         # Parking-related routes
│   ├── services
│   │   └── parking_service.py  # Business logic for parking operations
│   └── main.py                # Entry point of the application
├── tests
│   └── test_parking_service.py # Tests for parking service functions
├── requirements.txt            # Project dependencies
├── .env.example                # Environment variable template
├── alembic.ini                # Database migration configuration
└── README.md                   # Project documentation
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd smart-parking-navigator
   ```

2. Create a virtual environment:
   ```
   python -m venv venv
   ```

3. Activate the virtual environment:
   - On Windows:
     ```
     venv\Scripts\activate
     ```
   - On macOS/Linux:
     ```
     source venv/bin/activate
     ```

4. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

5. Set up the environment variables:
   - Copy `.env.example` to `.env` and fill in the required values.

## Running the Application

To start the application, run:
```
uvicorn app.main:app --reload --port 48100
```

The application will be available at `http://127.0.0.1:48100`.

## Demo Runner

The project includes scripts that start both the FastAPI backend and the Vite frontend using paths relative to the project folder. They also prepare the demo database.

Before the first run on Raspberry Pi, Linux, or macOS:
```
bash setup_demo.sh
```

On Windows PowerShell:
```
.\run_demo.ps1
```

On Raspberry Pi, Linux, or macOS:
```
bash run_demo.sh
```

To stop the background demo servers:
```
bash stop_demo.sh
```

The script tries to auto-detect the computer or Raspberry Pi IP address. If you want to open the app from another device on the same network and the printed URL is not reachable, pass the IP address explicitly:
```
bash run_demo.sh 192.168.1.50
```

The demo will use:
- Frontend: `http://<host>:48101`
- Backend: `http://<host>:48100`
- API docs: `http://<host>:48100/docs`

The setup script creates `.venv`, installs Python dependencies, installs frontend dependencies, seeds demo data, runs backend tests, and checks the frontend build.

The run script starts the backend and frontend fully in the background, writes their PIDs to `demo_logs/backend.pid` and `demo_logs/frontend.pid`, then returns control to the terminal. Use `bash stop_demo.sh` to stop both servers. Logs are written to `demo_logs/backend.log` and `demo_logs/frontend.log`.

Demo accounts:
- `admin@smartparking.local / admin123`
- `operator@smartparking.local / operator123`
- `driver@smartparking.local / driver123`

## API Documentation

The API documentation can be accessed at:
- Swagger UI: `http://127.0.0.1:48100/docs`
- ReDoc: `http://127.0.0.1:48100/redoc`

## Testing

To run the tests, use:
```
pytest tests/
```

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.

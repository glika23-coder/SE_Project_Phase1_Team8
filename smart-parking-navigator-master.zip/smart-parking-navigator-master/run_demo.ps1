param(
    [string]$ApiHost = "127.0.0.1",
    [int]$BackendPort = 48100,
    [int]$FrontendPort = 48101
)

$ErrorActionPreference = "Stop"
$RootDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$VenvPython = Join-Path $RootDir ".venv\Scripts\python.exe"
$FrontendDir = Join-Path $RootDir "frontend"
$NpmCommand = (Get-Command npm.cmd -ErrorAction SilentlyContinue).Source
if (-not $NpmCommand) {
    $NpmCommand = (Get-Command npm -ErrorAction Stop).Source
}

Set-Location $RootDir

if (-not (Test-Path $VenvPython)) {
    Write-Host "Python virtual environment is missing."
    Write-Host "Run setup first: bash setup_demo.sh on Linux/Pi, or create .venv and install requirements on Windows."
    exit 1
}

Write-Host "Preparing demo database..."
& $VenvPython (Join-Path $RootDir "scripts\seed_demo_data.py")

if (-not (Test-Path (Join-Path $FrontendDir "node_modules"))) {
    Write-Host "Frontend dependencies are missing." 
    Write-Host "Run setup first before starting the demo."
    exit 1
}

$env:VITE_API_BASE_URL = "http://${ApiHost}:$BackendPort"

Write-Host "Starting backend on http://0.0.0.0:$BackendPort"
$Backend = Start-Process `
    -FilePath $VenvPython `
    -ArgumentList @("-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "$BackendPort") `
    -WorkingDirectory $RootDir `
    -WindowStyle Hidden `
    -PassThru

Write-Host "Starting frontend on http://0.0.0.0:$FrontendPort"
$Frontend = Start-Process `
    -FilePath $NpmCommand `
    -ArgumentList @("run", "dev", "--", "--host", "0.0.0.0", "--port", "$FrontendPort") `
    -WorkingDirectory $FrontendDir `
    -WindowStyle Hidden `
    -PassThru

Write-Host ""
Write-Host "Demo is starting."
Write-Host "Frontend: http://${ApiHost}:$FrontendPort"
Write-Host "Backend:  http://${ApiHost}:$BackendPort"
Write-Host "API docs: http://${ApiHost}:$BackendPort/docs"
Write-Host ""
Write-Host "Demo accounts:"
Write-Host "  admin@smartparking.local / admin123"
Write-Host "  operator@smartparking.local / operator123"
Write-Host "  driver@smartparking.local / driver123"
Write-Host ""
Write-Host "Press Ctrl+C here to stop both servers."

try {
    while (-not $Backend.HasExited -and -not $Frontend.HasExited) {
        Start-Sleep -Seconds 1
        $Backend.Refresh()
        $Frontend.Refresh()
    }
}
finally {
    Stop-Process -Id $Backend.Id -Force -ErrorAction SilentlyContinue
    Stop-Process -Id $Frontend.Id -Force -ErrorAction SilentlyContinue
}

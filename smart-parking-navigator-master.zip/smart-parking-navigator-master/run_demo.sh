#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_PORT="${BACKEND_PORT:-48100}"
FRONTEND_PORT="${FRONTEND_PORT:-48101}"
VENV_DIR="$ROOT_DIR/.venv"
LOG_DIR="$ROOT_DIR/demo_logs"
BACKEND_PID_FILE="$LOG_DIR/backend.pid"
FRONTEND_PID_FILE="$LOG_DIR/frontend.pid"

detect_api_host() {
  local detected_host=""
  if command -v hostname >/dev/null 2>&1; then
    detected_host="$(hostname -I 2>/dev/null | awk '{print $1}')"
  fi

  if [ -n "$detected_host" ]; then
    echo "$detected_host"
  else
    echo "127.0.0.1"
  fi
}

API_HOST="${API_HOST:-${1:-$(detect_api_host)}}"

cd "$ROOT_DIR"

if [ ! -x "$VENV_DIR/bin/python" ]; then
  echo "Python virtual environment is missing."
  echo "Run setup first: bash setup_demo.sh"
  exit 1
fi

echo "Preparing demo database..."
"$VENV_DIR/bin/python" "$ROOT_DIR/scripts/seed_demo_data.py"

if [ ! -d "$ROOT_DIR/frontend/node_modules" ]; then
  echo "Frontend dependencies are missing."
  echo "Run setup first: bash setup_demo.sh"
  exit 1
fi

mkdir -p "$LOG_DIR"
BACKEND_LOG="$LOG_DIR/backend.log"
FRONTEND_LOG="$LOG_DIR/frontend.log"

is_running() {
  local pid_file="$1"
  if [ ! -f "$pid_file" ]; then
    return 1
  fi

  local pid
  pid="$(cat "$pid_file" 2>/dev/null || true)"
  if [ -z "$pid" ]; then
    return 1
  fi

  kill -0 "$pid" 2>/dev/null
}

if is_running "$BACKEND_PID_FILE" || is_running "$FRONTEND_PID_FILE"; then
  echo "Demo servers already appear to be running."
  echo "Stop them first with: bash stop_demo.sh"
  exit 1
fi

echo "Starting backend on http://0.0.0.0:$BACKEND_PORT"
setsid "$VENV_DIR/bin/python" -m uvicorn app.main:app --host 0.0.0.0 --port "$BACKEND_PORT" >"$BACKEND_LOG" 2>&1 &
BACKEND_PID=$!
echo "$BACKEND_PID" >"$BACKEND_PID_FILE"

echo "Starting frontend on http://0.0.0.0:$FRONTEND_PORT"
setsid bash -c "cd '$ROOT_DIR/frontend' && VITE_API_BASE_URL='http://$API_HOST:$BACKEND_PORT' exec npm run dev -- --host 0.0.0.0 --port '$FRONTEND_PORT'" >"$FRONTEND_LOG" 2>&1 &
FRONTEND_PID=$!
echo "$FRONTEND_PID" >"$FRONTEND_PID_FILE"

sleep 3

if ! kill -0 "$BACKEND_PID" 2>/dev/null; then
  echo "Backend stopped unexpectedly. Last backend log lines:"
  tail -n 30 "$BACKEND_LOG" || true
  rm -f "$BACKEND_PID_FILE"
  if kill -0 "$FRONTEND_PID" 2>/dev/null; then
    kill -- "-$FRONTEND_PID" 2>/dev/null || kill "$FRONTEND_PID" 2>/dev/null || true
  fi
  rm -f "$FRONTEND_PID_FILE"
  exit 1
fi

if ! kill -0 "$FRONTEND_PID" 2>/dev/null; then
  echo "Frontend stopped unexpectedly. Last frontend log lines:"
  tail -n 30 "$FRONTEND_LOG" || true
  rm -f "$FRONTEND_PID_FILE"
  if kill -0 "$BACKEND_PID" 2>/dev/null; then
    kill -- "-$BACKEND_PID" 2>/dev/null || kill "$BACKEND_PID" 2>/dev/null || true
  fi
  rm -f "$BACKEND_PID_FILE"
  exit 1
fi

echo
echo "Demo is running in the background."
echo "Frontend: http://$API_HOST:$FRONTEND_PORT"
echo "Backend:  http://$API_HOST:$BACKEND_PORT"
echo "API docs: http://$API_HOST:$BACKEND_PORT/docs"
echo "Backend log:  $BACKEND_LOG"
echo "Frontend log: $FRONTEND_LOG"
echo "Backend PID:  $BACKEND_PID"
echo "Frontend PID: $FRONTEND_PID"
echo
echo "Demo accounts:"
echo "  admin@smartparking.local / admin123"
echo "  operator@smartparking.local / operator123"
echo "  driver@smartparking.local / driver123"
echo
echo "Stop the demo with: bash stop_demo.sh"

import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Gauge, Minus, Plus, RefreshCcw } from "lucide-react";
import { ErrorBanner } from "../components/ErrorBanner";
import { LoadingBlock } from "../components/LoadingBlock";
import { StatusPill } from "../components/StatusPill";
import { api } from "../lib/api";
import type { ApiError, ParkingSpace } from "../types";

export function OperatorConsolePage() {
  const queryClient = useQueryClient();
  const operatorLocation = useQuery({
    queryKey: ["operator-location"],
    queryFn: api.getOperatorLocation,
    refetchInterval: 10000,
  });

  if (operatorLocation.isLoading) {
    return <LoadingBlock label="Loading operator console" />;
  }

  if (operatorLocation.isError) {
    return (
      <div className="mx-auto max-w-2xl">
        <ErrorBanner message={(operatorLocation.error as ApiError).message || "Could not load assigned location."} />
      </div>
    );
  }

  const data = operatorLocation.data;

  return (
    <div className="space-y-5">
      <section className="rounded-lg border border-curb bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold">
              <Gauge size={25} />
              Operator console
            </h1>
            <p className="mt-1 text-sm text-stone-600">{data?.location.name}</p>
          </div>
          <button
            type="button"
            className="secondary-button"
            onClick={() => queryClient.invalidateQueries({ queryKey: ["operator-location"] })}
          >
            <RefreshCcw size={17} />
            Refresh
          </button>
        </div>
      </section>

      <section className="grid gap-4">
        {(data?.parking_spaces ?? []).map((space) => (
          <OperatorParkingCounter key={space.parking_id} space={space} />
        ))}
      </section>
    </div>
  );
}

function OperatorParkingCounter({ space }: { space: ParkingSpace }) {
  const queryClient = useQueryClient();
  const [value, setValue] = useState(space.available_spots);

  useEffect(() => {
    setValue(space.available_spots);
  }, [space.available_spots]);

  const mutation = useMutation({
    mutationFn: (nextValue: number) =>
      api.updateOperatorAvailability(space.parking_id, { available_spots: nextValue }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["operator-location"] });
      queryClient.invalidateQueries({ queryKey: ["parking"] });
      queryClient.invalidateQueries({ queryKey: ["parking-search"] });
    },
  });

  const submitValue = (nextValue: number) => {
    const boundedValue = Math.max(0, Math.min(space.total_spots, nextValue));
    setValue(boundedValue);
    mutation.mutate(boundedValue);
  };

  return (
    <article className="rounded-lg border border-curb bg-white p-5 shadow-sm">
      <div className="grid gap-5 md:grid-cols-[1fr_auto] md:items-center">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-lg font-semibold">{space.name}</h2>
            <StatusPill space={{ ...space, available_spots: value, availability_status: value > 0 }} />
          </div>
          <p className="mt-1 text-sm text-stone-600">
            {value} of {space.total_spots} spaces available
          </p>
        </div>

        <div className="grid grid-cols-[64px_minmax(92px,120px)_64px] items-end gap-3">
          <button
            type="button"
            className="counter-button"
            disabled={mutation.isPending || value <= 0}
            onClick={() => submitValue(value - 1)}
            aria-label={`Decrease ${space.name} availability`}
          >
            <Minus size={28} />
          </button>
          <label className="field compact-field">
            <span>Available</span>
            <input
              type="number"
              min={0}
              max={space.total_spots}
              value={value}
              onChange={(event) => setValue(Number(event.target.value))}
              onBlur={() => submitValue(value)}
            />
          </label>
          <button
            type="button"
            className="counter-button"
            disabled={mutation.isPending || value >= space.total_spots}
            onClick={() => submitValue(value + 1)}
            aria-label={`Increase ${space.name} availability`}
          >
            <Plus size={28} />
          </button>
        </div>
      </div>
      {mutation.isError && <p className="mt-3 text-sm text-alert">{(mutation.error as ApiError).message}</p>}
      {mutation.isSuccess && <p className="mt-3 text-sm text-pine">Availability updated.</p>}
    </article>
  );
}

import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CarFront, Plus, RefreshCcw } from "lucide-react";
import { useForm } from "react-hook-form";
import { ErrorBanner } from "../components/ErrorBanner";
import { LoadingBlock } from "../components/LoadingBlock";
import { StatusPill } from "../components/StatusPill";
import { api } from "../lib/api";
import {
  parkingAdminUpdateSchema,
  parkingSchema,
  type ParkingAdminUpdateFormData,
  type ParkingFormData,
} from "../lib/schemas";
import type { ApiError, ParkingSpace } from "../types";

export function ParkingManagementPage() {
  const queryClient = useQueryClient();
  const locations = useQuery({ queryKey: ["locations"], queryFn: api.listLocations });
  const parking = useQuery({ queryKey: ["parking", false], queryFn: () => api.listParking(false) });
  const form = useForm<ParkingFormData>({
    resolver: zodResolver(parkingSchema),
    defaultValues: { location_id: 0, name: "", total_spots: 10, available_spots: 5 },
  });

  const createMutation = useMutation({
    mutationFn: api.createParking,
    onSuccess: () => {
      form.reset({ location_id: 0, name: "", total_spots: 10, available_spots: 5 });
      queryClient.invalidateQueries({ queryKey: ["parking"] });
    },
  });

  return (
    <div className="grid gap-5 xl:grid-cols-[420px_1fr]">
      <section className="rounded-lg border border-curb bg-white p-5 shadow-sm">
        <h1 className="flex items-center gap-2 text-2xl font-bold">
          <CarFront size={24} />
          Parking spaces
        </h1>
        <p className="mt-1 text-sm text-stone-600">Create parking spaces and keep availability current.</p>
        <form onSubmit={form.handleSubmit((values) => createMutation.mutate(values))} className="mt-5 space-y-4">
          <label className="field">
            <span>Location</span>
            <select {...form.register("location_id")}>
              <option value={0}>Choose a location</option>
              {(locations.data ?? []).map((location) => (
                <option key={location.location_id} value={location.location_id}>
                  {location.name}
                </option>
              ))}
            </select>
            {form.formState.errors.location_id && <small>{form.formState.errors.location_id.message}</small>}
          </label>
          <label className="field">
            <span>Parking name</span>
            <input {...form.register("name")} />
            {form.formState.errors.name && <small>{form.formState.errors.name.message}</small>}
          </label>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="field">
              <span>Total spots</span>
              <input type="number" min={0} {...form.register("total_spots")} />
              {form.formState.errors.total_spots && <small>{form.formState.errors.total_spots.message}</small>}
            </label>
            <label className="field">
              <span>Available spots</span>
              <input type="number" min={0} {...form.register("available_spots")} />
              {form.formState.errors.available_spots && (
                <small>{form.formState.errors.available_spots.message}</small>
              )}
            </label>
          </div>
          {createMutation.isError && <ErrorBanner message={(createMutation.error as ApiError).message} />}
          <button
            type="submit"
            className="primary-button w-full justify-center"
            disabled={createMutation.isPending || locations.isLoading}
          >
            <Plus size={18} />
            {createMutation.isPending ? "Creating" : "Create parking space"}
          </button>
        </form>
      </section>

      <section className="rounded-lg border border-curb bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold">Current parking spaces</h2>
        {parking.isLoading ? (
          <div className="mt-4">
            <LoadingBlock />
          </div>
        ) : parking.isError ? (
          <div className="mt-4">
            <ErrorBanner message="Could not load parking spaces." />
          </div>
        ) : (
          <div className="mt-4 grid gap-3">
            {(parking.data ?? []).map((space) => (
              <AvailabilityRow key={space.parking_id} space={space} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function AvailabilityRow({ space }: { space: ParkingSpace }) {
  const queryClient = useQueryClient();
  const form = useForm<ParkingAdminUpdateFormData>({
    resolver: zodResolver(parkingAdminUpdateSchema),
    defaultValues: { total_spots: space.total_spots, available_spots: space.available_spots },
  });

  const mutation = useMutation({
    mutationFn: (values: ParkingAdminUpdateFormData) => api.updateParking(space.parking_id, values),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["parking"] }),
  });

  const totalSpots = form.watch("total_spots");
  const availableSpots = form.watch("available_spots");

  return (
    <div className="rounded-lg border border-curb bg-road p-4">
      <div className="grid gap-4 lg:grid-cols-[1fr_280px] lg:items-center">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-semibold">{space.name}</h3>
            <StatusPill space={space} />
          </div>
          <p className="mt-1 text-sm text-stone-600">
            {space.location.name} · {space.available_spots} of {space.total_spots} spots available
          </p>
        </div>
        <form onSubmit={form.handleSubmit((values) => mutation.mutate(values))} className="grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
          <label className="field compact-field">
            <span>Total</span>
            <input type="number" min={0} {...form.register("total_spots")} />
          </label>
          <label className="field compact-field">
            <span>Available</span>
            <input type="number" min={0} max={totalSpots} {...form.register("available_spots")} />
          </label>
          <button type="submit" className="secondary-button self-end" disabled={mutation.isPending}>
            <RefreshCcw size={17} />
            Update
          </button>
          {Number(totalSpots) < space.available_spots && (
            <small className="sm:col-span-3 text-amber-700">
              Reducing capacity below current availability will also reduce availability.
            </small>
          )}
          {Number(availableSpots) > Number(totalSpots) && (
            <small className="sm:col-span-3 text-alert">Available spots cannot exceed total spots.</small>
          )}
          {form.formState.errors.available_spots && (
            <small className="sm:col-span-3 text-alert">{form.formState.errors.available_spots.message}</small>
          )}
          {form.formState.errors.total_spots && (
            <small className="sm:col-span-3 text-alert">{form.formState.errors.total_spots.message}</small>
          )}
          {mutation.isError && <small className="sm:col-span-3 text-alert">{(mutation.error as ApiError).message}</small>}
        </form>
      </div>
    </div>
  );
}

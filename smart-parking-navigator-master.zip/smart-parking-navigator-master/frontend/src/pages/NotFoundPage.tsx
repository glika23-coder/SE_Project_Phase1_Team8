import { Link } from "react-router-dom";

export function NotFoundPage() {
  return (
    <div className="mx-auto max-w-lg rounded-lg border border-curb bg-white p-8 text-center shadow-sm">
      <h1 className="text-3xl font-bold">Page not found</h1>
      <p className="mt-3 text-stone-600">The page you are looking for is not part of this parking workspace.</p>
      <Link to="/" className="primary-button mt-6 inline-flex">
        Back to search
      </Link>
    </div>
  );
}

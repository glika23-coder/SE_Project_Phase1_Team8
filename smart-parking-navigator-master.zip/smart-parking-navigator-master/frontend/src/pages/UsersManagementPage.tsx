import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { UsersRound } from "lucide-react";
import { ErrorBanner } from "../components/ErrorBanner";
import { LoadingBlock } from "../components/LoadingBlock";
import { api } from "../lib/api";
import type { ApiError, Location, User } from "../types";

const roles: User["role"][] = ["driver", "operator", "admin"];

export function UsersManagementPage() {
  const users = useQuery({ queryKey: ["users"], queryFn: api.listUsers });
  const locations = useQuery({ queryKey: ["locations"], queryFn: api.listLocations });

  if (users.isLoading || locations.isLoading) {
    return <LoadingBlock label="Loading users" />;
  }

  return (
    <div className="space-y-5">
      <section className="rounded-lg border border-curb bg-white p-5 shadow-sm">
        <h1 className="flex items-center gap-2 text-2xl font-bold">
          <UsersRound size={24} />
          Users
        </h1>
        <p className="mt-1 text-sm text-stone-600">Set roles and assign operators to parking locations.</p>
      </section>

      {(users.isError || locations.isError) && <ErrorBanner message="Could not load user management data." />}

      <section className="rounded-lg border border-curb bg-white p-5 shadow-sm">
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>Email</th>
                <th>Role</th>
                <th>Assigned location</th>
              </tr>
            </thead>
            <tbody>
              {(users.data ?? []).map((user) => (
                <UserRow key={user.user_id} user={user} locations={locations.data ?? []} />
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function UserRow({ user, locations }: { user: User; locations: Location[] }) {
  const queryClient = useQueryClient();
  const roleMutation = useMutation({
    mutationFn: (role: User["role"]) => api.updateUserRole(user.user_id, { role }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["users"] });
      queryClient.invalidateQueries({ queryKey: ["me"] });
    },
  });
  const assignmentMutation = useMutation({
    mutationFn: (assignedLocationId: number | null) =>
      api.updateUserAssignment(user.user_id, { assigned_location_id: assignedLocationId }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["users"] }),
  });

  const error = roleMutation.error || assignmentMutation.error;

  return (
    <tr>
      <td>
        <div className="font-medium">{user.email}</div>
        {error && <div className="mt-1 text-xs text-alert">{(error as ApiError).message}</div>}
      </td>
      <td>
        <select
          className="min-h-10 rounded-md border border-curb bg-white px-3 text-sm"
          value={user.role}
          disabled={roleMutation.isPending}
          onChange={(event) => roleMutation.mutate(event.target.value as User["role"])}
        >
          {roles.map((role) => (
            <option key={role} value={role}>
              {role}
            </option>
          ))}
        </select>
      </td>
      <td>
        <select
          className="min-h-10 rounded-md border border-curb bg-white px-3 text-sm"
          value={user.assigned_location_id ?? ""}
          disabled={user.role !== "operator" || assignmentMutation.isPending}
          onChange={(event) =>
            assignmentMutation.mutate(event.target.value ? Number(event.target.value) : null)
          }
        >
          <option value="">No assignment</option>
          {locations.map((location) => (
            <option key={location.location_id} value={location.location_id}>
              {location.name}
            </option>
          ))}
        </select>
      </td>
    </tr>
  );
}

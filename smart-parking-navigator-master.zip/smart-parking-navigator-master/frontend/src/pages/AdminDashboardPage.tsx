import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { CarFront, MapPinned, PlusCircle, UsersRound } from "lucide-react";
import { api } from "../lib/api";
import { isParkingAvailable } from "../lib/parking";
import { ErrorBanner } from "../components/ErrorBanner";
import { LoadingBlock } from "../components/LoadingBlock";

export function AdminDashboardPage() {
  const locations = useQuery({ queryKey: ["locations"], queryFn: api.listLocations });
  const parking = useQuery({ queryKey: ["parking", false], queryFn: () => api.listParking(false) });

  if (locations.isLoading || parking.isLoading) {
    return <LoadingBlock label="Loading dashboard" />;
  }

  const spaces = parking.data ?? [];
  const availableCount = spaces.filter(isParkingAvailable).length;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">Admin dashboard</h1>
        <p className="mt-1 text-sm text-stone-600">Manage the data that powers parking search.</p>
      </div>
      {(locations.isError || parking.isError) && <ErrorBanner message="Could not load dashboard data." />}
      <section className="grid gap-4 md:grid-cols-3">
        <MetricCard label="Locations" value={locations.data?.length ?? 0} icon={<MapPinned size={22} />} />
        <MetricCard label="Parking spaces" value={spaces.length} icon={<CarFront size={22} />} />
        <MetricCard label="Available spaces" value={availableCount} icon={<PlusCircle size={22} />} />
      </section>
      <section className="grid gap-4 md:grid-cols-3">
        <Link className="admin-link-card" to="/admin/locations">
          <MapPinned size={24} />
          <span>
            <strong>Locations</strong>
            <small>Create and review parking locations.</small>
          </span>
        </Link>
        <Link className="admin-link-card" to="/admin/parking">
          <CarFront size={24} />
          <span>
            <strong>Parking spaces</strong>
            <small>Add parking spaces and update availability.</small>
          </span>
        </Link>
        <Link className="admin-link-card" to="/admin/users">
          <UsersRound size={24} />
          <span>
            <strong>Users</strong>
            <small>Assign roles and operator locations.</small>
          </span>
        </Link>
      </section>
    </div>
  );
}

function MetricCard({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-curb bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-stone-600">{label}</span>
        <span className="text-pine">{icon}</span>
      </div>
      <p className="mt-3 text-3xl font-bold">{value}</p>
    </div>
  );
}

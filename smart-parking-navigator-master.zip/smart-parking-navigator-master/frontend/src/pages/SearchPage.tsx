import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Filter, LocateFixed, Search } from "lucide-react";
import { api } from "../lib/api";
import { withDistance } from "../lib/parking";
import type { ParkingWithDistance } from "../types";
import { EmptyState } from "../components/EmptyState";
import { ErrorBanner } from "../components/ErrorBanner";
import { LoadingBlock } from "../components/LoadingBlock";
import { ParkingCard } from "../components/ParkingCard";
import { ParkingDetailPanel } from "../components/ParkingDetailPanel";
import { ParkingMap } from "../components/ParkingMap";

type SearchMode = "all" | "name" | "nearby";

export function SearchPage() {
  const [query, setQuery] = useState("");
  const [submittedQuery, setSubmittedQuery] = useState("");
  const [availableOnly, setAvailableOnly] = useState(false);
  const [radiusKm, setRadiusKm] = useState(5);
  const [mode, setMode] = useState<SearchMode>("all");
  const [origin, setOrigin] = useState<{ latitude: number; longitude: number } | undefined>();
  const [geoError, setGeoError] = useState<string | null>(null);
  const [selected, setSelected] = useState<ParkingWithDistance | null>(null);

  const parkingQuery = useQuery({
    queryKey: ["parking-search", mode, submittedQuery, availableOnly, radiusKm, origin],
    queryFn: async () => {
      if (mode === "name" && submittedQuery.trim()) {
        return api.searchParking(submittedQuery.trim(), availableOnly);
      }
      if (mode === "nearby" && origin) {
        return api.nearbyParking({
          latitude: origin.latitude,
          longitude: origin.longitude,
          radius_km: radiusKm,
          available_only: availableOnly,
        });
      }
      return api.listParking(availableOnly);
    },
    refetchInterval: 10000,
  });

  const spaces = useMemo(
    () => withDistance(parkingQuery.data ?? [], mode === "nearby" ? origin : undefined),
    [mode, origin, parkingQuery.data],
  );

  const handleSearch = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setGeoError(null);
    if (!query.trim()) {
      setMode("all");
      setSubmittedQuery("");
      return;
    }
    setMode("name");
    setSubmittedQuery(query.trim());
    setSelected(null);
  };

  const useCurrentLocation = () => {
    setGeoError(null);
    if (!navigator.geolocation) {
      setGeoError("Your browser does not support location detection.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setOrigin({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
        setMode("nearby");
        setSelected(null);
      },
      () => {
        setGeoError("Location permission was denied. You can still search by location name.");
      },
      { enableHighAccuracy: true, timeout: 8000 },
    );
  };

  return (
    <div className="space-y-5">
      <section className="rounded-lg border border-curb bg-white p-5 shadow-sm">
        <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-end">
          <div>
            <h1 className="text-2xl font-bold">Find parking near you</h1>
            <p className="mt-1 text-sm text-stone-600">
              Search by location name or use your current position to see nearby parking spaces.
            </p>
          </div>
          <button type="button" onClick={useCurrentLocation} className="primary-button">
            <LocateFixed size={18} />
            Use my location
          </button>
        </div>
        <form onSubmit={handleSearch} className="mt-5 grid gap-3 md:grid-cols-[1fr_auto_auto]">
          <label className="field">
            <span>Location name</span>
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search by area, mall, or station"
            />
          </label>
          <label className="field min-w-40">
            <span>Radius</span>
            <select value={radiusKm} onChange={(event) => setRadiusKm(Number(event.target.value))}>
              {[1, 2, 5, 10, 25, 50].map((value) => (
                <option key={value} value={value}>
                  {value} km
                </option>
              ))}
            </select>
          </label>
          <button type="submit" className="primary-button self-end">
            <Search size={18} />
            Search
          </button>
        </form>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <label className="inline-flex items-center gap-2 text-sm font-medium">
            <input
              type="checkbox"
              checked={availableOnly}
              onChange={(event) => setAvailableOnly(event.target.checked)}
              className="h-4 w-4 accent-pine"
            />
            Available spaces only
          </label>
          <span className="inline-flex items-center gap-1 text-xs text-stone-500">
            <Filter size={14} />
            Showing {mode === "nearby" ? "nearby results" : mode === "name" ? "search results" : "all parking"}
          </span>
        </div>
        {geoError && (
          <div className="mt-4">
            <ErrorBanner message={geoError} />
          </div>
        )}
      </section>

      {parkingQuery.isError && <ErrorBanner message="API server is unavailable or returned an error. Try again." />}

      <section className="grid gap-5 lg:grid-cols-[minmax(0,1.1fr)_minmax(360px,0.9fr)]">
        <ParkingMap
          spaces={spaces}
          selectedId={selected?.parking_id}
          onSelect={(space) => setSelected(space)}
        />
        <div className="space-y-4">
          <ParkingDetailPanel space={selected} onClose={() => setSelected(null)} />
          {parkingQuery.isLoading ? (
            <LoadingBlock label="Loading parking spaces" />
          ) : spaces.length === 0 ? (
            <EmptyState
              title="No parking spaces found"
              body="Try a different search term, increase the radius, or turn off the availability filter."
            />
          ) : (
            <div className="grid gap-3">
              {spaces.map((space) => (
                <ParkingCard
                  key={space.parking_id}
                  space={space}
                  isSelected={selected?.parking_id === space.parking_id}
                  onSelect={setSelected}
                />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

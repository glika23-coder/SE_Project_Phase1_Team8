import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { UserPlus } from "lucide-react";
import { useForm } from "react-hook-form";
import { Link, useNavigate } from "react-router-dom";
import { ErrorBanner } from "../components/ErrorBanner";
import { api } from "../lib/api";
import { registerSchema, type RegisterFormData } from "../lib/schemas";
import type { ApiError } from "../types";

export function RegisterPage() {
  const navigate = useNavigate();
  const form = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: { email: "", password: "" },
  });

  const mutation = useMutation({
    mutationFn: api.register,
    onSuccess: () => navigate("/login"),
  });

  return (
    <div className="mx-auto max-w-md rounded-lg border border-curb bg-white p-6 shadow-sm">
      <h1 className="text-2xl font-bold">Create account</h1>
      <p className="mt-1 text-sm text-stone-600">Register to manage locations and parking spaces.</p>
      <form onSubmit={form.handleSubmit((values) => mutation.mutate(values))} className="mt-6 space-y-4">
        <label className="field">
          <span>Email</span>
          <input type="email" {...form.register("email")} />
          {form.formState.errors.email && <small>{form.formState.errors.email.message}</small>}
        </label>
        <label className="field">
          <span>Password</span>
          <input type="password" {...form.register("password")} />
          {form.formState.errors.password && <small>{form.formState.errors.password.message}</small>}
        </label>
        {mutation.isError && <ErrorBanner message={(mutation.error as ApiError).message} />}
        <button type="submit" className="primary-button w-full justify-center" disabled={mutation.isPending}>
          <UserPlus size={18} />
          {mutation.isPending ? "Creating account" : "Register"}
        </button>
      </form>
      <p className="mt-5 text-center text-sm text-stone-600">
        Already registered?{" "}
        <Link className="font-semibold text-pine hover:underline" to="/login">
          Login
        </Link>
      </p>
    </div>
  );
}

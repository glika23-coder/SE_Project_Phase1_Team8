import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { LogIn } from "lucide-react";
import { useForm } from "react-hook-form";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { ErrorBanner } from "../components/ErrorBanner";
import { LoadingBlock } from "../components/LoadingBlock";
import { api } from "../lib/api";
import { canAccessPath, getRoleHome } from "../lib/access";
import { loginSchema, type LoginFormData } from "../lib/schemas";
import type { ApiError } from "../types";

export function LoginPage() {
  const { isAuthenticated, isLoadingUser, loginWithToken, logout, user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const queryClient = useQueryClient();
  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  const mutation = useMutation({
    mutationFn: api.login,
    onSuccess: async (data) => {
      loginWithToken(data.access_token);
      try {
        const nextUser = await api.me();
        queryClient.setQueryData(["me", data.access_token], nextUser);
        const requestedPath = (location.state as { from?: string } | null)?.from;
        const destination =
          requestedPath && canAccessPath(nextUser.role, requestedPath)
            ? requestedPath
            : getRoleHome(nextUser.role);
        navigate(destination, { replace: true });
      } catch (error) {
        logout();
        throw error;
      }
    },
  });

  if (isAuthenticated && isLoadingUser) {
    return <LoadingBlock label="Checking access" />;
  }

  if (user) {
    return <Navigate to={getRoleHome(user.role)} replace />;
  }

  return (
    <div className="mx-auto max-w-md rounded-lg border border-curb bg-white p-6 shadow-sm">
      <h1 className="text-2xl font-bold">Login</h1>
      <p className="mt-1 text-sm text-stone-600">Use your account to manage parking data.</p>
      <form onSubmit={form.handleSubmit((values) => mutation.mutate(values))} className="mt-6 space-y-4">
        <label className="field">
          <span>Email</span>
          <input type="email" {...form.register("email")} />
          {form.formState.errors.email && <small>{form.formState.errors.email.message}</small>}
        </label>
        <label className="field">
          <span>Password</span>
          <input type="password" {...form.register("password")} />
          {form.formState.errors.password && <small>{form.formState.errors.password.message}</small>}
        </label>
        {mutation.isError && <ErrorBanner message={(mutation.error as ApiError).message} />}
        <button type="submit" className="primary-button w-full justify-center" disabled={mutation.isPending}>
          <LogIn size={18} />
          {mutation.isPending ? "Logging in" : "Login"}
        </button>
      </form>
      <p className="mt-5 text-center text-sm text-stone-600">
        Need an account?{" "}
        <Link className="font-semibold text-pine hover:underline" to="/register">
          Register
        </Link>
      </p>
    </div>
  );
}

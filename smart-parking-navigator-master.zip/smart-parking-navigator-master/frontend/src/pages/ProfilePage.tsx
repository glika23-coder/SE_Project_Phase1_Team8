import { Mail, UserRound } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { LoadingBlock } from "../components/LoadingBlock";
import { api } from "../lib/api";

export function ProfilePage() {
  const { user, isLoadingUser, logout } = useAuth();
  const navigate = useNavigate();
  const locations = useQuery({
    queryKey: ["locations"],
    queryFn: api.listLocations,
    enabled: user?.role === "operator",
  });
  const assignedLocation = locations.data?.find((location) => location.location_id === user?.assigned_location_id);

  if (isLoadingUser) return <LoadingBlock label="Loading profile" />;

  return (
    <div className="mx-auto max-w-xl rounded-lg border border-curb bg-white p-6 shadow-sm">
      <div className="flex items-center gap-3">
        <span className="grid h-12 w-12 place-items-center rounded-md bg-mint text-pine">
          <UserRound size={24} />
        </span>
        <div>
          <h1 className="text-2xl font-bold">Profile</h1>
          <p className="text-sm text-stone-600">Authenticated management account</p>
        </div>
      </div>
      <dl className="mt-6 grid gap-3">
        <div className="rounded-md bg-road p-4">
          <dt className="flex items-center gap-2 text-sm text-stone-500">
            <Mail size={16} />
            Email
          </dt>
          <dd className="mt-1 font-semibold">{user?.email}</dd>
        </div>
        <div className="rounded-md bg-road p-4">
          <dt className="text-sm text-stone-500">User ID</dt>
          <dd className="mt-1 font-semibold">{user?.user_id}</dd>
        </div>
        <div className="rounded-md bg-road p-4">
          <dt className="text-sm text-stone-500">Role</dt>
          <dd className="mt-1 font-semibold capitalize">{user?.role}</dd>
        </div>
        {user?.role === "operator" && (
          <div className="rounded-md bg-road p-4">
            <dt className="text-sm text-stone-500">Assigned location</dt>
            <dd className="mt-1 font-semibold">{assignedLocation?.name ?? "No assigned location"}</dd>
          </div>
        )}
      </dl>
      <button
        type="button"
        className="secondary-button mt-6"
        onClick={() => {
          logout();
          navigate("/login");
        }}
      >
        Logout
      </button>
    </div>
  );
}

import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { MapPinned, Plus } from "lucide-react";
import { useForm } from "react-hook-form";
import { ErrorBanner } from "../components/ErrorBanner";
import { LoadingBlock } from "../components/LoadingBlock";
import { api } from "../lib/api";
import { locationSchema, type LocationFormData } from "../lib/schemas";
import type { ApiError } from "../types";

export function LocationsPage() {
  const queryClient = useQueryClient();
  const locations = useQuery({ queryKey: ["locations"], queryFn: api.listLocations });
  const form = useForm<LocationFormData>({
    resolver: zodResolver(locationSchema),
    defaultValues: { name: "", latitude: 50.8503, longitude: 4.3517 },
  });

  const mutation = useMutation({
    mutationFn: api.createLocation,
    onSuccess: () => {
      form.reset({ name: "", latitude: 50.8503, longitude: 4.3517 });
      queryClient.invalidateQueries({ queryKey: ["locations"] });
    },
  });

  return (
    <div className="grid gap-5 lg:grid-cols-[380px_1fr]">
      <section className="rounded-lg border border-curb bg-white p-5 shadow-sm">
        <h1 className="flex items-center gap-2 text-2xl font-bold">
          <MapPinned size={24} />
          Locations
        </h1>
        <p className="mt-1 text-sm text-stone-600">Add coordinates where parking spaces belong.</p>
        <form onSubmit={form.handleSubmit((values) => mutation.mutate(values))} className="mt-5 space-y-4">
          <label className="field">
            <span>Name</span>
            <input {...form.register("name")} />
            {form.formState.errors.name && <small>{form.formState.errors.name.message}</small>}
          </label>
          <label className="field">
            <span>Latitude</span>
            <input type="number" step="any" {...form.register("latitude")} />
            {form.formState.errors.latitude && <small>{form.formState.errors.latitude.message}</small>}
          </label>
          <label className="field">
            <span>Longitude</span>
            <input type="number" step="any" {...form.register("longitude")} />
            {form.formState.errors.longitude && <small>{form.formState.errors.longitude.message}</small>}
          </label>
          {mutation.isError && <ErrorBanner message={(mutation.error as ApiError).message} />}
          <button type="submit" className="primary-button w-full justify-center" disabled={mutation.isPending}>
            <Plus size={18} />
            {mutation.isPending ? "Creating" : "Create location"}
          </button>
        </form>
      </section>
      <section className="rounded-lg border border-curb bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold">Existing locations</h2>
        {locations.isLoading ? (
          <div className="mt-4">
            <LoadingBlock />
          </div>
        ) : locations.isError ? (
          <div className="mt-4">
            <ErrorBanner message="Could not load locations." />
          </div>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Latitude</th>
                  <th>Longitude</th>
                </tr>
              </thead>
              <tbody>
                {(locations.data ?? []).map((location) => (
                  <tr key={location.location_id}>
                    <td>{location.name}</td>
                    <td>{location.latitude.toFixed(5)}</td>
                    <td>{location.longitude.toFixed(5)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

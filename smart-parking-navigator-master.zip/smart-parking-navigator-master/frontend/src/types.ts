export type User = {
  user_id: number;
  email: string;
  role: "driver" | "operator" | "admin";
  assigned_location_id: number | null;
};

export type TokenResponse = {
  access_token: string;
  token_type: "bearer";
};

export type Location = {
  location_id: number;
  name: string;
  latitude: number;
  longitude: number;
};

export type ParkingSpace = {
  parking_id: number;
  name: string;
  availability_status: boolean;
  total_spots: number;
  available_spots: number;
  updated_at: string | null;
  location: Location;
};

export type ApiErrorPayload = {
  detail?: string | Array<{ loc?: Array<string | number>; msg?: string; type?: string }>;
};

export type ApiError = Error & {
  status?: number;
  payload?: ApiErrorPayload;
};

export type ParkingWithDistance = ParkingSpace & {
  distanceKm?: number;
};

export type OperatorLocation = {
  location: Location;
  parking_spaces: ParkingSpace[];
};

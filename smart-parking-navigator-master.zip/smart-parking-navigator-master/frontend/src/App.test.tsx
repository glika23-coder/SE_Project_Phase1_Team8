import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router-dom";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { AuthProvider } from "./auth/AuthContext";
import { App } from "./App";
import { api } from "./lib/api";
import type { Location, OperatorLocation, ParkingSpace, User } from "./types";

vi.mock("./lib/api", () => ({
  api: {
    getOperatorLocation: vi.fn(),
    listLocations: vi.fn(),
    listParking: vi.fn(),
    login: vi.fn(),
    me: vi.fn(),
    searchParking: vi.fn(),
    nearbyParking: vi.fn(),
  },
}));

vi.mock("./components/ParkingMap", () => ({
  ParkingMap: () => <div data-testid="parking-map" />,
}));

const TOKEN_KEY = "smart-parking-token";

const users: Record<User["role"], User> = {
  driver: {
    user_id: 1,
    email: "driver@smartparking.local",
    role: "driver",
    assigned_location_id: null,
  },
  operator: {
    user_id: 2,
    email: "operator@smartparking.local",
    role: "operator",
    assigned_location_id: 1,
  },
  admin: {
    user_id: 3,
    email: "admin@smartparking.local",
    role: "admin",
    assigned_location_id: null,
  },
};

const location: Location = {
  location_id: 1,
  name: "Skanderbeg Square",
  latitude: 41.3275,
  longitude: 19.8189,
};

const parking: ParkingSpace = {
  parking_id: 1,
  name: "Skanderbeg Underground Parking",
  availability_status: true,
  total_spots: 180,
  available_spots: 42,
  updated_at: null,
  location,
};

const operatorLocation: OperatorLocation = {
  location,
  parking_spaces: [parking],
};

function renderApp(initialPath: string, user?: User) {
  if (user) {
    window.localStorage.setItem(TOKEN_KEY, `${user.role}-token`);
    vi.mocked(api.me).mockResolvedValue(user);
  }

  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false },
    },
  });

  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={[initialPath]}>
        <AuthProvider>
          <App />
        </AuthProvider>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

beforeEach(() => {
  window.localStorage.clear();
  vi.clearAllMocks();
  vi.mocked(api.getOperatorLocation).mockResolvedValue(operatorLocation);
  vi.mocked(api.listLocations).mockResolvedValue([location]);
  vi.mocked(api.listParking).mockResolvedValue([parking]);
  vi.mocked(api.searchParking).mockResolvedValue([parking]);
  vi.mocked(api.nearbyParking).mockResolvedValue([parking]);
});

describe("role-gated app access", () => {
  it("starts unauthenticated visitors at login and keeps registration public", async () => {
    renderApp("/");

    expect(await screen.findByRole("heading", { name: /login/i })).toBeInTheDocument();
    expect(screen.getAllByRole("link", { name: /register/i }).length).toBeGreaterThan(0);
  });

  it.each(["/search", "/operator", "/admin", "/profile"])(
    "redirects unauthenticated access to %s back to login",
    async (path) => {
      renderApp(path);

      expect(await screen.findByRole("heading", { name: /login/i })).toBeInTheDocument();
    },
  );

  it("allows unauthenticated visitors to open registration", async () => {
    renderApp("/register");

    expect(await screen.findByRole("heading", { name: /create account/i })).toBeInTheDocument();
  });

  it("shows only driver navigation and search for driver users", async () => {
    renderApp("/", users.driver);

    expect(await screen.findByRole("heading", { name: /find parking near you/i })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /search/i })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /driver@smartparking\.local/i })).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: /^operator$/i })).not.toBeInTheDocument();
    expect(screen.queryByRole("link", { name: /^admin$/i })).not.toBeInTheDocument();
  });

  it("shows only operator navigation and console for operator users", async () => {
    renderApp("/", users.operator);

    expect(await screen.findByRole("heading", { name: /operator console/i })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /^operator$/i })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /operator@smartparking\.local/i })).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: /search/i })).not.toBeInTheDocument();
    expect(screen.queryByRole("link", { name: /^admin$/i })).not.toBeInTheDocument();
  });

  it("shows only admin navigation and dashboard for admin users", async () => {
    renderApp("/", users.admin);

    expect(await screen.findByRole("heading", { name: /admin dashboard/i })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /^admin$/i })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /^users$/i })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /admin@smartparking\.local/i })).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: /search/i })).not.toBeInTheDocument();
    expect(screen.queryByRole("link", { name: /^operator$/i })).not.toBeInTheDocument();
  });

  it("redirects wrong-role route access to the user's own home", async () => {
    renderApp("/operator", users.driver);

    expect(await screen.findByRole("heading", { name: /find parking near you/i })).toBeInTheDocument();
  });

  it.each([
    [users.driver, /find parking near you/i],
    [users.operator, /operator console/i],
    [users.admin, /admin dashboard/i],
  ])("redirects login success to the %s role home", async (nextUser, heading) => {
    const user = userEvent.setup();
    vi.mocked(api.login).mockResolvedValue({ access_token: `${nextUser.role}-token`, token_type: "bearer" });
    vi.mocked(api.me).mockResolvedValue(nextUser);

    renderApp("/login");

    await user.type(screen.getByLabelText(/email/i), nextUser.email);
    await user.type(screen.getByLabelText(/password/i), "password123");
    await user.click(screen.getByRole("button", { name: /login/i }));

    await waitFor(() => expect(api.me).toHaveBeenCalled());
    expect(await screen.findByRole("heading", { name: heading })).toBeInTheDocument();
  });
});

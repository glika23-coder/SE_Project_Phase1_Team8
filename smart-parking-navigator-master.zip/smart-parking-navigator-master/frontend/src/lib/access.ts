import type { User } from "../types";

export function getRoleHome(role: User["role"]): string {
  if (role === "driver") return "/search";
  if (role === "operator") return "/operator";
  return "/admin";
}

export function canAccessPath(role: User["role"], path: string): boolean {
  const normalizedPath = path === "/" ? getRoleHome(role) : path;

  if (normalizedPath === "/profile") return true;
  if (role === "driver") return normalizedPath === "/search";
  if (role === "operator") return normalizedPath === "/operator";
  return normalizedPath === "/admin" || normalizedPath.startsWith("/admin/");
}

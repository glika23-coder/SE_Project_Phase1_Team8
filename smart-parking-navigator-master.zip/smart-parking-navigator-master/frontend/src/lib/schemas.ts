import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email("Enter a valid email address."),
  password: z.string().min(1, "Password is required."),
});

export const registerSchema = z.object({
  email: z.string().email("Enter a valid email address."),
  password: z.string().min(8, "Password must be at least 8 characters."),
});

export const locationSchema = z.object({
  name: z.string().min(2, "Location name is required."),
  latitude: z.coerce.number().min(-90, "Latitude must be at least -90.").max(90, "Latitude cannot exceed 90."),
  longitude: z.coerce
    .number()
    .min(-180, "Longitude must be at least -180.")
    .max(180, "Longitude cannot exceed 180."),
});

export const parkingSchema = z
  .object({
    location_id: z.coerce.number().int().positive("Choose a location."),
    name: z.string().min(2, "Parking name is required."),
    total_spots: z.coerce.number().int().min(0, "Total spots cannot be negative."),
    available_spots: z.coerce.number().int().min(0, "Available spots cannot be negative."),
  })
  .refine((value) => value.available_spots <= value.total_spots, {
    message: "Available spots cannot exceed total spots.",
    path: ["available_spots"],
  });

export const availabilitySchema = z.object({
  available_spots: z.coerce.number().int().min(0, "Available spots cannot be negative."),
});

export const parkingAdminUpdateSchema = z
  .object({
    total_spots: z.coerce.number().int().min(0, "Total spots cannot be negative."),
    available_spots: z.coerce.number().int().min(0, "Available spots cannot be negative."),
  })
  .refine((value) => value.available_spots <= value.total_spots, {
    message: "Available spots cannot exceed total spots.",
    path: ["available_spots"],
  });

export type LoginFormData = z.infer<typeof loginSchema>;
export type RegisterFormData = z.infer<typeof registerSchema>;
export type LocationFormData = z.infer<typeof locationSchema>;
export type ParkingFormData = z.infer<typeof parkingSchema>;
export type AvailabilityFormData = z.infer<typeof availabilitySchema>;
export type ParkingAdminUpdateFormData = z.infer<typeof parkingAdminUpdateSchema>;

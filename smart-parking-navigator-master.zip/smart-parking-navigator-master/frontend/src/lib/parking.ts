import type { ParkingSpace, ParkingWithDistance } from "../types";

export function isParkingAvailable(space: Pick<ParkingSpace, "availability_status" | "available_spots">): boolean {
  return space.availability_status && space.available_spots > 0;
}

export function formatAvailability(space: Pick<ParkingSpace, "availability_status" | "available_spots">): string {
  return isParkingAvailable(space) ? "Available" : "Full";
}

export function formatUpdatedAt(value: string | null): string {
  if (!value) return "Not updated yet";
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const earthRadiusKm = 6371;
  const toRadians = (value: number) => (value * Math.PI) / 180;
  const phi1 = toRadians(lat1);
  const phi2 = toRadians(lat2);
  const deltaPhi = toRadians(lat2 - lat1);
  const deltaLambda = toRadians(lon2 - lon1);
  const a =
    Math.sin(deltaPhi / 2) ** 2 +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) ** 2;
  return earthRadiusKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function withDistance(
  spaces: ParkingSpace[],
  origin?: { latitude: number; longitude: number },
): ParkingWithDistance[] {
  if (!origin) return spaces;
  return spaces.map((space) => ({
    ...space,
    distanceKm: haversineKm(
      origin.latitude,
      origin.longitude,
      space.location.latitude,
      space.location.longitude,
    ),
  }));
}

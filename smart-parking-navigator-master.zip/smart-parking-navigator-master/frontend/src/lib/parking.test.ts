import { describe, expect, it } from "vitest";
import { formatAvailability, haversineKm, isParkingAvailable, withDistance } from "./parking";
import type { ParkingSpace } from "../types";

const baseSpace: ParkingSpace = {
  parking_id: 1,
  name: "Central Garage",
  availability_status: true,
  total_spots: 20,
  available_spots: 5,
  updated_at: null,
  location: {
    location_id: 1,
    name: "Central",
    latitude: 50.8503,
    longitude: 4.3517,
  },
};

describe("parking helpers", () => {
  it("marks parking as available only when status is true and spots remain", () => {
    expect(isParkingAvailable(baseSpace)).toBe(true);
    expect(formatAvailability(baseSpace)).toBe("Available");
    expect(isParkingAvailable({ ...baseSpace, available_spots: 0 })).toBe(false);
    expect(formatAvailability({ ...baseSpace, availability_status: false })).toBe("Full");
  });

  it("calculates known coordinate distances", () => {
    expect(haversineKm(51.5074, -0.1278, 48.8566, 2.3522)).toBeCloseTo(343.5, 0);
  });

  it("adds distance when an origin is provided", () => {
    const [space] = withDistance([baseSpace], { latitude: 50.8503, longitude: 4.3517 });
    expect(space.distanceKm).toBeCloseTo(0);
  });
});

import { describe, expect, it } from "vitest";
import { locationSchema, parkingSchema, registerSchema } from "./schemas";

describe("form schemas", () => {
  it("requires valid registration values", () => {
    expect(registerSchema.safeParse({ email: "driver@example.com", password: "secret123" }).success).toBe(true);
    expect(registerSchema.safeParse({ email: "bad", password: "short" }).success).toBe(false);
  });

  it("validates location coordinate bounds", () => {
    expect(locationSchema.safeParse({ name: "Central", latitude: 50.8, longitude: 4.3 }).success).toBe(true);
    expect(locationSchema.safeParse({ name: "Central", latitude: 91, longitude: 4.3 }).success).toBe(false);
  });

  it("prevents parking availability from exceeding capacity", () => {
    expect(
      parkingSchema.safeParse({
        location_id: 1,
        name: "Central Garage",
        total_spots: 10,
        available_spots: 5,
      }).success,
    ).toBe(true);
    expect(
      parkingSchema.safeParse({
        location_id: 1,
        name: "Central Garage",
        total_spots: 10,
        available_spots: 11,
      }).success,
    ).toBe(false);
  });
});

import type { ApiError, Location, OperatorLocation, ParkingSpace, TokenResponse, User } from "../types";
import { clearStoredToken, getStoredToken } from "./storage";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://127.0.0.1:48100";

type RequestOptions = RequestInit & {
  auth?: boolean;
};

async function parseError(response: Response): Promise<ApiError> {
  let payload;
  try {
    payload = await response.json();
  } catch {
    payload = undefined;
  }
  const detail = Array.isArray(payload?.detail)
    ? payload.detail.map((item: { msg?: string }) => item.msg).filter(Boolean).join(" ")
    : payload?.detail;
  const error = new Error(detail || `Request failed with status ${response.status}`) as ApiError;
  error.status = response.status;
  error.payload = payload;
  return error;
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const headers = new Headers(options.headers);
  const token = getStoredToken();

  if (!(options.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  if (options.auth && token) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    if (response.status === 401 && options.auth) {
      clearStoredToken();
      window.dispatchEvent(new CustomEvent("auth:expired"));
    }
    throw await parseError(response);
  }

  return response.json() as Promise<T>;
}

export const api = {
  health: () => request<{ status: string }>("/"),
  register: (payload: { email: string; password: string }) =>
    request<User>("/api/v1/auth/register", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  login: (payload: { email: string; password: string }) => {
    const body = new URLSearchParams();
    body.set("username", payload.email);
    body.set("password", payload.password);
    return request<TokenResponse>("/api/v1/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
  },
  me: () => request<User>("/api/v1/users/me", { auth: true }),
  listUsers: () => request<User[]>("/api/v1/users/", { auth: true }),
  updateUserRole: (userId: number, payload: { role: User["role"] }) =>
    request<User>(`/api/v1/users/${userId}/role`, {
      method: "PATCH",
      auth: true,
      body: JSON.stringify(payload),
    }),
  updateUserAssignment: (userId: number, payload: { assigned_location_id: number | null }) =>
    request<User>(`/api/v1/users/${userId}/assignment`, {
      method: "PATCH",
      auth: true,
      body: JSON.stringify(payload),
    }),
  listLocations: () => request<Location[]>("/api/v1/locations/"),
  getLocation: (locationId: number) => request<Location>(`/api/v1/locations/${locationId}`),
  createLocation: (payload: { name: string; latitude: number; longitude: number }) =>
    request<Location>("/api/v1/locations/", {
      method: "POST",
      auth: true,
      body: JSON.stringify(payload),
    }),
  listParking: (availableOnly = false) =>
    request<ParkingSpace[]>(`/api/v1/parking/?available_only=${availableOnly}`),
  searchParking: (query: string, availableOnly = false) =>
    request<ParkingSpace[]>(
      `/api/v1/parking/search?q=${encodeURIComponent(query)}&available_only=${availableOnly}`,
      { auth: Boolean(getStoredToken()) },
    ),
  nearbyParking: (params: {
    latitude: number;
    longitude: number;
    radius_km?: number;
    available_only?: boolean;
  }) => {
    const search = new URLSearchParams({
      latitude: String(params.latitude),
      longitude: String(params.longitude),
      radius_km: String(params.radius_km ?? 5),
      available_only: String(params.available_only ?? false),
    });
    return request<ParkingSpace[]>(`/api/v1/parking/nearby?${search.toString()}`, {
      auth: Boolean(getStoredToken()),
    });
  },
  getParking: (parkingId: number) => request<ParkingSpace>(`/api/v1/parking/${parkingId}`),
  createParking: (payload: {
    location_id: number;
    name: string;
    total_spots: number;
    available_spots: number;
  }) =>
    request<ParkingSpace>("/api/v1/parking/", {
      method: "POST",
      auth: true,
      body: JSON.stringify(payload),
    }),
  updateParking: (
    parkingId: number,
    payload: { available_spots?: number; total_spots?: number },
  ) =>
    request<ParkingSpace>(`/api/v1/parking/${parkingId}`, {
      method: "PATCH",
      auth: true,
      body: JSON.stringify(payload),
    }),
  getOperatorLocation: () => request<OperatorLocation>("/api/v1/operator/location", { auth: true }),
  updateOperatorAvailability: (parkingId: number, payload: { available_spots: number }) =>
    request<ParkingSpace>(`/api/v1/operator/parking/${parkingId}/availability`, {
      method: "PATCH",
      auth: true,
      body: JSON.stringify(payload),
    }),
};

import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./auth/AuthContext";
import { Layout } from "./components/Layout";
import { LoadingBlock } from "./components/LoadingBlock";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { getRoleHome } from "./lib/access";
import { AdminDashboardPage } from "./pages/AdminDashboardPage";
import { LocationsPage } from "./pages/LocationsPage";
import { LoginPage } from "./pages/LoginPage";
import { NotFoundPage } from "./pages/NotFoundPage";
import { ParkingManagementPage } from "./pages/ParkingManagementPage";
import { ProfilePage } from "./pages/ProfilePage";
import { RegisterPage } from "./pages/RegisterPage";
import { SearchPage } from "./pages/SearchPage";
import { OperatorConsolePage } from "./pages/OperatorConsolePage";
import { UsersManagementPage } from "./pages/UsersManagementPage";

export function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<RoleHomeRedirect />} />
        <Route path="login" element={<LoginPage />} />
        <Route path="register" element={<RegisterPage />} />
        <Route element={<ProtectedRoute allowedRoles={["driver"]} />}>
          <Route path="search" element={<SearchPage />} />
        </Route>
        <Route element={<ProtectedRoute />}>
          <Route path="profile" element={<ProfilePage />} />
        </Route>
        <Route element={<ProtectedRoute allowedRoles={["operator"]} />}>
          <Route path="operator" element={<OperatorConsolePage />} />
        </Route>
        <Route element={<ProtectedRoute allowedRoles={["admin"]} />}>
          <Route path="admin" element={<AdminDashboardPage />} />
          <Route path="admin/locations" element={<LocationsPage />} />
          <Route path="admin/parking" element={<ParkingManagementPage />} />
          <Route path="admin/users" element={<UsersManagementPage />} />
        </Route>
        <Route path="home" element={<Navigate to="/" replace />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}

function RoleHomeRedirect() {
  const { isAuthenticated, isLoadingUser, user } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (isLoadingUser || !user) {
    return <LoadingBlock label="Checking access" />;
  }

  return <Navigate to={getRoleHome(user.role)} replace />;
}

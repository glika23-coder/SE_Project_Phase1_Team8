import { SearchX } from "lucide-react";

export function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-lg border border-dashed border-curb bg-white/70 p-8 text-center">
      <SearchX className="mx-auto mb-3 text-pine" size={34} />
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="mt-2 text-sm text-stone-600">{body}</p>
    </div>
  );
}

export function LoadingBlock({ label = "Loading" }: { label?: string }) {
  return (
    <div className="rounded-lg border border-curb bg-white p-6 text-sm text-stone-600 shadow-sm">
      {label}...
    </div>
  );
}

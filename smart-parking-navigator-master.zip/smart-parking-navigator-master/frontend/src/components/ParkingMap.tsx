import { MapContainer, Marker, Popup, TileLayer, useMap } from "react-leaflet";
import L from "leaflet";
import type { ParkingWithDistance } from "../types";
import { isParkingAvailable } from "../lib/parking";
import "leaflet/dist/leaflet.css";

const availableIcon = new L.DivIcon({
  html: '<span class="map-marker map-marker-available"></span>',
  className: "",
  iconSize: [22, 22],
  iconAnchor: [11, 11],
});

const fullIcon = new L.DivIcon({
  html: '<span class="map-marker map-marker-full"></span>',
  className: "",
  iconSize: [22, 22],
  iconAnchor: [11, 11],
});

function FitBounds({ spaces }: { spaces: ParkingWithDistance[] }) {
  const map = useMap();
  const coordinates = spaces.map((space) => [space.location.latitude, space.location.longitude] as [number, number]);

  if (coordinates.length === 1) {
    map.setView(coordinates[0], 15);
  } else if (coordinates.length > 1) {
    map.fitBounds(coordinates, { padding: [36, 36], maxZoom: 15 });
  }

  return null;
}

export function ParkingMap({
  spaces,
  selectedId,
  onSelect,
}: {
  spaces: ParkingWithDistance[];
  selectedId?: number;
  onSelect: (space: ParkingWithDistance) => void;
}) {
  const center: [number, number] =
    spaces.length > 0 ? [spaces[0].location.latitude, spaces[0].location.longitude] : [50.8503, 4.3517];

  return (
    <div className="h-[420px] overflow-hidden rounded-lg border border-curb bg-white shadow-sm md:h-[620px]">
      <MapContainer center={center} zoom={13} scrollWheelZoom className="h-full w-full">
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <FitBounds spaces={spaces} />
        {spaces.map((space) => (
          <Marker
            key={space.parking_id}
            position={[space.location.latitude, space.location.longitude]}
            icon={isParkingAvailable(space) ? availableIcon : fullIcon}
            eventHandlers={{ click: () => onSelect(space) }}
            opacity={selectedId === space.parking_id ? 1 : 0.85}
          >
            <Popup>
              <strong>{space.name}</strong>
              <br />
              {space.available_spots} of {space.total_spots} spots available
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}

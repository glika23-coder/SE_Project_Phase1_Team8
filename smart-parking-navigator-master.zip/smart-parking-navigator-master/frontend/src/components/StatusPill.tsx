import { CheckCircle2, CircleSlash } from "lucide-react";
import { clsx } from "clsx";
import type { ParkingSpace } from "../types";
import { formatAvailability, isParkingAvailable } from "../lib/parking";

export function StatusPill({ space }: { space: Pick<ParkingSpace, "availability_status" | "available_spots"> }) {
  const available = isParkingAvailable(space);
  const Icon = available ? CheckCircle2 : CircleSlash;

  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold",
        available ? "bg-mint text-pine" : "bg-red-100 text-alert",
      )}
    >
      <Icon size={14} />
      {formatAvailability(space)}
    </span>
  );
}

import { LocateFixed, X } from "lucide-react";
import type { ParkingWithDistance } from "../types";
import { formatUpdatedAt } from "../lib/parking";
import { StatusPill } from "./StatusPill";

export function ParkingDetailPanel({
  space,
  onClose,
}: {
  space: ParkingWithDistance | null;
  onClose: () => void;
}) {
  if (!space) {
    return (
      <aside className="rounded-lg border border-curb bg-white p-5 shadow-sm">
        <h2 className="text-lg font-semibold">Parking details</h2>
        <p className="mt-2 text-sm text-stone-600">Choose a parking space from the list or map.</p>
      </aside>
    );
  }

  return (
    <aside className="rounded-lg border border-curb bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">{space.name}</h2>
          <p className="mt-1 text-sm text-stone-600">{space.location.name}</p>
        </div>
        <button type="button" onClick={onClose} className="icon-button" aria-label="Close details">
          <X size={18} />
        </button>
      </div>
      <div className="mt-4">
        <StatusPill space={space} />
      </div>
      <dl className="mt-5 grid grid-cols-2 gap-3 text-sm">
        <div className="rounded-md bg-road p-3">
          <dt className="text-stone-500">Available</dt>
          <dd className="mt-1 text-xl font-bold text-pine">{space.available_spots}</dd>
        </div>
        <div className="rounded-md bg-road p-3">
          <dt className="text-stone-500">Capacity</dt>
          <dd className="mt-1 text-xl font-bold">{space.total_spots}</dd>
        </div>
        <div className="col-span-2 rounded-md bg-road p-3">
          <dt className="text-stone-500">Last updated</dt>
          <dd className="mt-1 font-medium">{formatUpdatedAt(space.updated_at)}</dd>
        </div>
        <div className="col-span-2 rounded-md bg-road p-3">
          <dt className="flex items-center gap-1 text-stone-500">
            <LocateFixed size={15} />
            Coordinates
          </dt>
          <dd className="mt-1 font-medium">
            {space.location.latitude.toFixed(5)}, {space.location.longitude.toFixed(5)}
          </dd>
        </div>
      </dl>
    </aside>
  );
}

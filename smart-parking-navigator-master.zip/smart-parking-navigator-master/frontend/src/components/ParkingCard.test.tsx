import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { ParkingCard } from "./ParkingCard";
import type { ParkingSpace } from "../types";

const space: ParkingSpace = {
  parking_id: 1,
  name: "Central Garage",
  availability_status: true,
  total_spots: 30,
  available_spots: 12,
  updated_at: null,
  location: {
    location_id: 1,
    name: "Central Station",
    latitude: 50.8503,
    longitude: 4.3517,
  },
};

describe("ParkingCard", () => {
  it("shows availability and calls onSelect", async () => {
    const onSelect = vi.fn();
    render(<ParkingCard space={space} onSelect={onSelect} />);

    expect(screen.getByText("Central Garage")).toBeInTheDocument();
    expect(screen.getByText("Available")).toBeInTheDocument();
    expect(screen.getByText("12")).toBeInTheDocument();

    await userEvent.click(screen.getByRole("button", { name: /central garage/i }));
    expect(onSelect).toHaveBeenCalledWith(space);
  });
});

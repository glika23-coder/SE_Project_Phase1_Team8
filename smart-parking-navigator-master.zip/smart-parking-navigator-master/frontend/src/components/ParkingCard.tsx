import { Clock, MapPin, Navigation } from "lucide-react";
import { clsx } from "clsx";
import type { ParkingWithDistance } from "../types";
import { formatUpdatedAt, isParkingAvailable } from "../lib/parking";
import { StatusPill } from "./StatusPill";

type ParkingCardProps = {
  space: ParkingWithDistance;
  isSelected?: boolean;
  onSelect?: (space: ParkingWithDistance) => void;
};

export function ParkingCard({ space, isSelected, onSelect }: ParkingCardProps) {
  const available = isParkingAvailable(space);

  return (
    <button
      type="button"
      onClick={() => onSelect?.(space)}
      className={clsx(
        "w-full rounded-lg border bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-panel",
        isSelected ? "border-pine ring-2 ring-pine/20" : "border-curb",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold">{space.name}</h3>
          <p className="mt-1 flex items-center gap-1 text-sm text-stone-600">
            <MapPin size={15} />
            {space.location.name}
          </p>
        </div>
        <StatusPill space={space} />
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
        <div className="rounded-md bg-road p-3">
          <p className="text-stone-500">Available spots</p>
          <p className={clsx("mt-1 text-xl font-bold", available ? "text-pine" : "text-alert")}>
            {space.available_spots}
          </p>
        </div>
        <div className="rounded-md bg-road p-3">
          <p className="text-stone-500">Total spots</p>
          <p className="mt-1 text-xl font-bold">{space.total_spots}</p>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-stone-500">
        <span className="inline-flex items-center gap-1">
          <Clock size={14} />
          {formatUpdatedAt(space.updated_at)}
        </span>
        {typeof space.distanceKm === "number" && (
          <span className="inline-flex items-center gap-1">
            <Navigation size={14} />
            {space.distanceKm.toFixed(2)} km away
          </span>
        )}
      </div>
    </button>
  );
}

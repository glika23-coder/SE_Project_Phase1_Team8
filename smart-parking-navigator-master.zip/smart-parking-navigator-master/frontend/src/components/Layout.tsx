import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { CarFront, Gauge, LayoutDashboard, LogIn, LogOut, MapPinned, UserPlus, UsersRound, UserRound } from "lucide-react";
import { clsx } from "clsx";
import { useAuth } from "../auth/AuthContext";
import { getRoleHome } from "../lib/access";

const navLinkClass = ({ isActive }: { isActive: boolean }) =>
  clsx(
    "inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition",
    isActive ? "bg-pine text-white" : "text-ink hover:bg-mint",
  );

export function Layout() {
  const { isAuthenticated, user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-road text-ink">
      <header className="sticky top-0 z-40 border-b border-curb bg-road/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <Link to={user ? getRoleHome(user.role) : "/login"} className="flex items-center gap-2 text-lg font-bold">
            <span className="grid h-9 w-9 place-items-center rounded-md bg-pine text-white">
              <CarFront size={20} />
            </span>
            Smart Parking Navigator
          </Link>
          <nav className="flex flex-wrap items-center gap-2">
            {user?.role === "driver" && (
              <NavLink to="/search" className={navLinkClass}>
                <MapPinned size={17} />
                Search
              </NavLink>
            )}
            {user?.role === "operator" && (
              <NavLink to="/operator" className={navLinkClass}>
                <Gauge size={17} />
                Operator
              </NavLink>
            )}
            {user?.role === "admin" && (
              <NavLink to="/admin" className={navLinkClass}>
                <LayoutDashboard size={17} />
                Admin
              </NavLink>
            )}
            {user?.role === "admin" && (
              <NavLink to="/admin/users" className={navLinkClass}>
                <UsersRound size={17} />
                Users
              </NavLink>
            )}
            {isAuthenticated ? (
              <>
                <NavLink to="/profile" className={navLinkClass}>
                  <UserRound size={17} />
                  {user?.email ?? "Profile"}
                </NavLink>
                <button type="button" onClick={handleLogout} className="icon-text-button">
                  <LogOut size={17} />
                  Logout
                </button>
              </>
            ) : (
              <>
                <NavLink to="/login" className={navLinkClass}>
                  <LogIn size={17} />
                  Login
                </NavLink>
                <NavLink to="/register" className={navLinkClass}>
                  <UserPlus size={17} />
                  Register
                </NavLink>
              </>
            )}
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-6">
        <Outlet />
      </main>
    </div>
  );
}

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../lib/api";
import { clearStoredToken, getStoredToken, setStoredToken } from "../lib/storage";
import type { User } from "../types";

type AuthContextValue = {
  token: string | null;
  user: User | undefined;
  isAuthenticated: boolean;
  isLoadingUser: boolean;
  loginWithToken: (token: string) => void;
  logout: () => void;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(() => getStoredToken());
  const queryClient = useQueryClient();

  const userQuery = useQuery({
    queryKey: ["me", token],
    queryFn: api.me,
    enabled: Boolean(token),
    retry: false,
  });

  const logout = useCallback(() => {
    clearStoredToken();
    setToken(null);
    queryClient.removeQueries({ queryKey: ["me"] });
  }, [queryClient]);

  useEffect(() => {
    const handleExpired = () => logout();
    window.addEventListener("auth:expired", handleExpired);
    return () => window.removeEventListener("auth:expired", handleExpired);
  }, [logout]);

  useEffect(() => {
    if (token && userQuery.isError) {
      logout();
    }
  }, [logout, token, userQuery.isError]);

  const value = useMemo<AuthContextValue>(
    () => ({
      token,
      user: userQuery.data,
      isAuthenticated: Boolean(token),
      isLoadingUser: Boolean(token) && userQuery.isLoading,
      loginWithToken: (nextToken) => {
        setStoredToken(nextToken);
        setToken(nextToken);
        queryClient.invalidateQueries({ queryKey: ["me"] });
      },
      logout,
    }),
    [logout, queryClient, token, userQuery.data, userQuery.isLoading],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return value;
}

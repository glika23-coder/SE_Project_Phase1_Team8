/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#17211b",
        pine: "#1d5c45",
        mint: "#dff5e8",
        road: "#f4f1ea",
        curb: "#dde5df",
        signal: "#e1a100",
        alert: "#b34036",
      },
      boxShadow: {
        panel: "0 18px 50px rgba(23, 33, 27, 0.12)",
      },
    },
  },
  plugins: [],
};

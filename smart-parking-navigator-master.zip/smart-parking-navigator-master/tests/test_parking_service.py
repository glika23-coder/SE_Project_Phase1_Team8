import pytest

from app.services.parking_service import haversine_km


def test_haversine_zero_distance() -> None:
    assert haversine_km(0.0, 0.0, 0.0, 0.0) == pytest.approx(0.0)


def test_haversine_symmetry() -> None:
    distance_ab = haversine_km(51.5074, -0.1278, 40.7128, -74.0060)
    distance_ba = haversine_km(40.7128, -74.0060, 51.5074, -0.1278)
    assert distance_ab == pytest.approx(distance_ba)


def test_haversine_known_distance() -> None:
    distance = haversine_km(51.5074, -0.1278, 48.8566, 2.3522)
    assert distance == pytest.approx(343.5, rel=1e-2)

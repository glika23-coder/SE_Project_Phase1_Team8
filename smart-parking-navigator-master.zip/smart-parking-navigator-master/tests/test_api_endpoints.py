import os
from collections.abc import Generator

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

os.environ.setdefault("DATABASE_URL", "sqlite:///./test_api_import.db")

from app.core.database import Base, get_db
from app.main import app
from app.models.location import Location
from app.models.parking import ParkingSpace
from app.models.search_log import SearchLog
from app.models.user import User


@pytest.fixture()
def client() -> Generator[TestClient, None, None]:
    engine = create_engine(
        "sqlite+pysqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)

    def override_get_db() -> Generator[Session, None, None]:
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    app.router.on_startup.clear()
    app.state.TestingSessionLocal = TestingSessionLocal

    with TestClient(app) as test_client:
        yield test_client

    app.dependency_overrides.clear()
    del app.state.TestingSessionLocal
    Base.metadata.drop_all(bind=engine)
    engine.dispose()


def register_user(client: TestClient, email: str = "driver@example.com", password: str = "secret123") -> dict:
    response = client.post("/api/v1/auth/register", json={"email": email, "password": password})
    assert response.status_code == 201
    return response.json()


def set_user_role(client: TestClient, email: str, role: str, assigned_location_id: int | None = None) -> None:
    db = app.state.TestingSessionLocal()
    try:
        user = db.query(User).filter(User.email == email).first()
        assert user is not None
        user.role = role
        user.assigned_location_id = assigned_location_id
        db.commit()
    finally:
        db.close()


def auth_headers(
    client: TestClient,
    email: str = "admin@example.com",
    password: str = "secret123",
    role: str = "admin",
    assigned_location_id: int | None = None,
) -> dict[str, str]:
    register_user(client, email=email, password=password)
    set_user_role(client, email, role, assigned_location_id)
    response = client.post(
        "/api/v1/auth/login",
        data={"username": email, "password": password},
    )
    assert response.status_code == 200
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def create_location(
    client: TestClient,
    headers: dict[str, str],
    name: str = "Central Station",
    latitude: float = 50.8503,
    longitude: float = 4.3517,
) -> dict:
    response = client.post(
        "/api/v1/locations/",
        json={"name": name, "latitude": latitude, "longitude": longitude},
        headers=headers,
    )
    assert response.status_code == 201
    return response.json()


def create_parking_space(
    client: TestClient,
    headers: dict[str, str],
    location_id: int,
    name: str = "Central Garage",
    total_spots: int = 100,
    available_spots: int = 25,
) -> dict:
    response = client.post(
        "/api/v1/parking/",
        json={
            "location_id": location_id,
            "name": name,
            "total_spots": total_spots,
            "available_spots": available_spots,
        },
        headers=headers,
    )
    assert response.status_code == 201
    return response.json()


def test_health_check_returns_ok(client: TestClient) -> None:
    response = client.get("/")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_register_login_and_get_profile(client: TestClient) -> None:
    registered = register_user(client)

    assert registered["email"] == "driver@example.com"
    assert registered["role"] == "driver"
    assert registered["assigned_location_id"] is None
    assert "password" not in registered

    login_response = client.post(
        "/api/v1/auth/login",
        data={"username": "driver@example.com", "password": "secret123"},
    )
    assert login_response.status_code == 200
    token_body = login_response.json()
    assert token_body["token_type"] == "bearer"
    assert token_body["access_token"]

    profile_response = client.get(
        "/api/v1/users/me",
        headers={"Authorization": f"Bearer {token_body['access_token']}"},
    )
    assert profile_response.status_code == 200
    assert profile_response.json() == registered


def test_register_rejects_duplicate_email(client: TestClient) -> None:
    register_user(client)

    response = client.post(
        "/api/v1/auth/register",
        json={"email": "driver@example.com", "password": "secret123"},
    )

    assert response.status_code == 409
    assert response.json()["detail"] == "Email already registered"


def test_register_validates_email_and_password(client: TestClient) -> None:
    invalid_email = client.post(
        "/api/v1/auth/register",
        json={"email": "not-an-email", "password": "secret123"},
    )
    short_password = client.post(
        "/api/v1/auth/register",
        json={"email": "driver@example.com", "password": "short"},
    )

    assert invalid_email.status_code == 422
    assert short_password.status_code == 422


def test_login_rejects_bad_credentials(client: TestClient) -> None:
    register_user(client)

    response = client.post(
        "/api/v1/auth/login",
        data={"username": "driver@example.com", "password": "wrong-password"},
    )

    assert response.status_code == 401
    assert response.json()["detail"] == "Incorrect email or password"


def test_protected_endpoints_require_authentication(client: TestClient) -> None:
    location_response = client.post(
        "/api/v1/locations/",
        json={"name": "Central Station", "latitude": 50.8503, "longitude": 4.3517},
    )
    parking_response = client.post(
        "/api/v1/parking/",
        json={"location_id": 1, "name": "Central Garage", "total_spots": 10, "available_spots": 3},
    )
    profile_response = client.get("/api/v1/users/me")

    assert location_response.status_code == 401
    assert parking_response.status_code == 401
    assert profile_response.status_code == 401


def test_driver_and_operator_cannot_access_admin_endpoints(client: TestClient) -> None:
    driver_headers = auth_headers(client, email="driver2@example.com", role="driver")
    operator_headers = auth_headers(client, email="operator2@example.com", role="operator")

    driver_response = client.post(
        "/api/v1/locations/",
        json={"name": "Driver Lot", "latitude": 41.3275, "longitude": 19.8189},
        headers=driver_headers,
    )
    operator_response = client.post(
        "/api/v1/parking/",
        json={"location_id": 1, "name": "Operator Lot", "total_spots": 10, "available_spots": 4},
        headers=operator_headers,
    )
    users_response = client.get("/api/v1/users/", headers=operator_headers)

    assert driver_response.status_code == 403
    assert operator_response.status_code == 403
    assert users_response.status_code == 403


def test_locations_can_be_created_listed_and_retrieved(client: TestClient) -> None:
    headers = auth_headers(client)
    location = create_location(client, headers)

    list_response = client.get("/api/v1/locations/")
    detail_response = client.get(f"/api/v1/locations/{location['location_id']}")

    assert list_response.status_code == 200
    assert list_response.json() == [location]
    assert detail_response.status_code == 200
    assert detail_response.json() == location


def test_location_endpoints_validate_input_and_missing_records(client: TestClient) -> None:
    headers = auth_headers(client)

    invalid_create = client.post(
        "/api/v1/locations/",
        json={"name": "Bad Coordinates", "latitude": 91, "longitude": 4.3517},
        headers=headers,
    )
    missing_detail = client.get("/api/v1/locations/999")

    assert invalid_create.status_code == 422
    assert missing_detail.status_code == 404
    assert missing_detail.json()["detail"] == "Location not found"


def test_parking_can_be_created_listed_retrieved_and_filtered(client: TestClient) -> None:
    headers = auth_headers(client)
    location = create_location(client, headers)
    available = create_parking_space(client, headers, location["location_id"], available_spots=5)
    unavailable = create_parking_space(
        client,
        headers,
        location["location_id"],
        name="Full Garage",
        available_spots=0,
    )

    list_response = client.get("/api/v1/parking/")
    available_only_response = client.get("/api/v1/parking/?available_only=true")
    detail_response = client.get(f"/api/v1/parking/{available['parking_id']}")

    assert list_response.status_code == 200
    assert {space["parking_id"] for space in list_response.json()} == {
        available["parking_id"],
        unavailable["parking_id"],
    }
    assert available_only_response.status_code == 200
    assert [space["parking_id"] for space in available_only_response.json()] == [available["parking_id"]]
    assert detail_response.status_code == 200
    assert detail_response.json()["location"] == location


def test_create_parking_rejects_unknown_location(client: TestClient) -> None:
    headers = auth_headers(client)

    response = client.post(
        "/api/v1/parking/",
        json={"location_id": 999, "name": "Nowhere Garage", "total_spots": 10, "available_spots": 3},
        headers=headers,
    )

    assert response.status_code == 400
    assert response.json()["detail"] == "Location not found"


def test_patch_parking_updates_availability_and_validates_capacity(client: TestClient) -> None:
    headers = auth_headers(client)
    location = create_location(client, headers)
    parking = create_parking_space(client, headers, location["location_id"], total_spots=8, available_spots=4)

    update_response = client.patch(
        f"/api/v1/parking/{parking['parking_id']}",
        json={"available_spots": 0},
        headers=headers,
    )
    invalid_response = client.patch(
        f"/api/v1/parking/{parking['parking_id']}",
        json={"available_spots": 9},
        headers=headers,
    )
    missing_response = client.patch(
        "/api/v1/parking/999",
        json={"available_spots": 1},
        headers=headers,
    )

    assert update_response.status_code == 200
    assert update_response.json()["available_spots"] == 0
    assert update_response.json()["availability_status"] is False
    assert invalid_response.status_code == 400
    assert invalid_response.json()["detail"] == "available_spots cannot exceed total_spots"
    assert missing_response.status_code == 404
    assert missing_response.json()["detail"] == "Parking space not found"


def test_admin_can_update_capacity_and_availability_is_derived(client: TestClient) -> None:
    headers = auth_headers(client)
    location = create_location(client, headers)
    parking = create_parking_space(client, headers, location["location_id"], total_spots=10, available_spots=8)

    clamp_response = client.patch(
        f"/api/v1/parking/{parking['parking_id']}",
        json={"total_spots": 5},
        headers=headers,
    )
    zero_response = client.patch(
        f"/api/v1/parking/{parking['parking_id']}",
        json={"available_spots": 0},
        headers=headers,
    )

    assert clamp_response.status_code == 200
    assert clamp_response.json()["total_spots"] == 5
    assert clamp_response.json()["available_spots"] == 5
    assert clamp_response.json()["availability_status"] is True
    assert zero_response.status_code == 200
    assert zero_response.json()["availability_status"] is False


def test_admin_can_manage_users_and_operator_assignments(client: TestClient) -> None:
    admin_headers = auth_headers(client)
    operator = register_user(client, email="newoperator@example.com")
    location = create_location(client, admin_headers)

    users_response = client.get("/api/v1/users/", headers=admin_headers)
    role_response = client.patch(
        f"/api/v1/users/{operator['user_id']}/role",
        json={"role": "operator"},
        headers=admin_headers,
    )
    assignment_response = client.patch(
        f"/api/v1/users/{operator['user_id']}/assignment",
        json={"assigned_location_id": location["location_id"]},
        headers=admin_headers,
    )
    driver_response = client.patch(
        f"/api/v1/users/{operator['user_id']}/role",
        json={"role": "driver"},
        headers=admin_headers,
    )

    assert users_response.status_code == 200
    assert role_response.status_code == 200
    assert role_response.json()["role"] == "operator"
    assert assignment_response.status_code == 200
    assert assignment_response.json()["assigned_location_id"] == location["location_id"]
    assert driver_response.status_code == 200
    assert driver_response.json()["role"] == "driver"
    assert driver_response.json()["assigned_location_id"] is None


def test_operator_can_only_update_assigned_location_availability(client: TestClient) -> None:
    admin_headers = auth_headers(client)
    assigned_location = create_location(client, admin_headers, name="Assigned Lot")
    other_location = create_location(client, admin_headers, name="Other Lot", latitude=41.32, longitude=19.82)
    assigned_space = create_parking_space(client, admin_headers, assigned_location["location_id"], total_spots=6, available_spots=2)
    other_space = create_parking_space(client, admin_headers, other_location["location_id"], total_spots=6, available_spots=2)
    operator_headers = auth_headers(
        client,
        email="assignedoperator@example.com",
        role="operator",
        assigned_location_id=assigned_location["location_id"],
    )

    location_response = client.get("/api/v1/operator/location", headers=operator_headers)
    update_response = client.patch(
        f"/api/v1/operator/parking/{assigned_space['parking_id']}/availability",
        json={"available_spots": 5},
        headers=operator_headers,
    )
    too_many_response = client.patch(
        f"/api/v1/operator/parking/{assigned_space['parking_id']}/availability",
        json={"available_spots": 7},
        headers=operator_headers,
    )
    outside_response = client.patch(
        f"/api/v1/operator/parking/{other_space['parking_id']}/availability",
        json={"available_spots": 3},
        headers=operator_headers,
    )
    admin_patch_response = client.patch(
        f"/api/v1/parking/{assigned_space['parking_id']}",
        json={"total_spots": 12},
        headers=operator_headers,
    )

    assert location_response.status_code == 200
    assert location_response.json()["location"]["location_id"] == assigned_location["location_id"]
    assert [space["parking_id"] for space in location_response.json()["parking_spaces"]] == [assigned_space["parking_id"]]
    assert update_response.status_code == 200
    assert update_response.json()["available_spots"] == 5
    assert too_many_response.status_code == 400
    assert outside_response.status_code == 404
    assert admin_patch_response.status_code == 403


def test_operator_without_assignment_gets_clear_error(client: TestClient) -> None:
    operator_headers = auth_headers(client, email="unassignedoperator@example.com", role="operator")

    response = client.get("/api/v1/operator/location", headers=operator_headers)

    assert response.status_code == 400
    assert response.json()["detail"] == "Operator is not assigned to a location"


def test_search_parking_by_location_name_and_available_filter(client: TestClient) -> None:
    headers = auth_headers(client)
    central = create_location(client, headers, name="Central Station")
    south = create_location(client, headers, name="South Station", latitude=50.835, longitude=4.336)
    create_parking_space(client, headers, central["location_id"], name="Central Open", available_spots=3)
    create_parking_space(client, headers, central["location_id"], name="Central Full", available_spots=0)
    create_parking_space(client, headers, south["location_id"], name="South Open", available_spots=4)

    response = client.get("/api/v1/parking/search?q=central&available_only=true", headers=headers)

    assert response.status_code == 200
    results = response.json()
    assert len(results) == 1
    assert results[0]["name"] == "Central Open"


def test_nearby_parking_returns_matches_sorted_and_validates_query(client: TestClient) -> None:
    headers = auth_headers(client)
    near = create_location(client, headers, name="Near Lot", latitude=50.8503, longitude=4.3517)
    farther = create_location(client, headers, name="Farther Lot", latitude=50.8600, longitude=4.3600)
    remote = create_location(client, headers, name="Remote Lot", latitude=51.2194, longitude=4.4025)
    near_space = create_parking_space(client, headers, near["location_id"], name="Near Garage")
    farther_space = create_parking_space(client, headers, farther["location_id"], name="Farther Garage")
    create_parking_space(client, headers, remote["location_id"], name="Remote Garage")

    response = client.get(
        "/api/v1/parking/nearby",
        params={"latitude": 50.8503, "longitude": 4.3517, "radius_km": 5},
        headers=headers,
    )
    invalid_response = client.get(
        "/api/v1/parking/nearby",
        params={"latitude": 91, "longitude": 4.3517, "radius_km": 5},
    )

    assert response.status_code == 200
    assert [space["parking_id"] for space in response.json()] == [
        near_space["parking_id"],
        farther_space["parking_id"],
    ]
    assert invalid_response.status_code == 422


def test_search_and_nearby_create_search_logs(client: TestClient) -> None:
    headers = auth_headers(client)
    location = create_location(client, headers)
    create_parking_space(client, headers, location["location_id"])

    client.get("/api/v1/parking/search?q=central", headers=headers)
    client.get(
        "/api/v1/parking/nearby",
        params={"latitude": 50.8503, "longitude": 4.3517},
        headers=headers,
    )

    db = app.state.TestingSessionLocal()
    try:
        logs = db.query(SearchLog).order_by(SearchLog.log_id).all()
        assert len(logs) == 2
        assert logs[0].query == "central"
        assert logs[0].results_count == 1
        assert logs[1].latitude == pytest.approx(50.8503)
        assert logs[1].longitude == pytest.approx(4.3517)
        assert logs[1].results_count == 1
    finally:
        db.close()

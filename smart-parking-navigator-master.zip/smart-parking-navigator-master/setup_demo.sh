#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$ROOT_DIR/.venv"

cd "$ROOT_DIR"

require_command() {
  local command_name="$1"
  local install_hint="$2"

  if ! command -v "$command_name" >/dev/null 2>&1; then
    echo "Missing required command: $command_name"
    echo "$install_hint"
    exit 1
  fi
}

require_command "python3" "Install it with: sudo apt update && sudo apt install -y python3 python3-venv python3-pip"
require_command "npm" "Install Node.js and npm with: sudo apt update && sudo apt install -y nodejs npm"

if [ ! -x "$VENV_DIR/bin/python" ]; then
  echo "Creating Python virtual environment..."
  python3 -m venv "$VENV_DIR"
fi

echo "Upgrading pip..."
"$VENV_DIR/bin/python" -m pip install --upgrade pip

echo "Installing backend dependencies..."
"$VENV_DIR/bin/python" -m pip install -r "$ROOT_DIR/requirements.txt"

echo "Installing frontend dependencies..."
(
  cd "$ROOT_DIR/frontend"
  if [ -f package-lock.json ]; then
    npm ci
  else
    npm install
  fi
)

echo "Preparing demo database and sample data..."
"$VENV_DIR/bin/python" "$ROOT_DIR/scripts/seed_demo_data.py"

echo "Checking backend tests..."
"$VENV_DIR/bin/python" -m pytest

echo "Checking frontend build..."
(
  cd "$ROOT_DIR/frontend"
  npm run build
)

echo
echo "Setup complete."
echo "Start the demo with:"
echo "  bash run_demo.sh <your-pi-ip>"
echo "Stop the demo with:"
echo "  bash stop_demo.sh"
echo
echo "Example:"
echo "  bash run_demo.sh 192.168.1.50"
